# MoyuKit 摸鱼工具箱

MoyuKit 是一套面向课题组 Linux 服务器用户的快捷工具集合，用于简化常见操作、减少重复命令输入。

少敲几行命令，多留一点时间。

## 用户级全局安装

MoyuKit 采用用户级全局安装：文件默认放在当前用户自己的目录中，不写入 `/usr`、`/etc`、`/opt` 等系统目录，也不需要 `sudo`。安装脚本只会修改当前用户的 `~/.bashrc`，并且只维护带固定标记的 MoyuKit 加载区块。

默认安装目录：

```bash
$HOME/.local/share/moyukit
```

自定义安装目录：

```bash
bash install.sh --dir "$HOME/tools/moyukit"
```

安装完成后，当前终端需要执行一次：

```bash
source ~/.bashrc
```

之后新建 Bash 终端会自动加载 MoyuKit。

## 安装

普通用户可以一行安装：

```bash
tmp="$(mktemp -d)" && curl -fsSL https://ithecover.com/software/moyukit/install.sh -o "$tmp/install.sh" && MOYUKIT_SERVER_URL=https://ithecover.com/software/moyukit bash "$tmp/install.sh"
```

开发目录中的本地测试安装：

```bash
bash install.sh --local-source /data6A/wuying/projects/MoyuKit
```

发布服务器地址为：

```text
https://ithecover.com/software/moyukit
```

## Conda 环境行为

MoyuKit 的命令由 Bash 加载。切换 Conda 环境后，`tless`、`nf`、`rr`、`moyu` 这些 Bash 函数仍然存在。实际调用哪个外部程序取决于当前环境的 `PATH`，例如 `rr` 使用的 `Rscript` 就由当前 Conda 环境或系统路径决定。

## tless

`tless` 是 table less 的缩写，用于对齐并分页查看表格。

```bash
tless file.tsv
tless file.vcf
tless file.vcf.gz
command | tless
```

参数：

```text
-H, --header    显示以 ## 开头的元信息行
-n N            显示前 N 行有效数据，N 可以为 0，0 表示全部
-a, -A, --all   显示全部有效数据
```

默认行为：

```text
隐藏以 ## 开头的元信息行
保留 #CHROM 等不以 ## 开头的列名行
默认显示前 100 行非 ## 行
支持普通文件、.gz 文件和标准输入
使用 column -t 对齐
使用 less -S 分页，支持左右方向键查看宽表格
```

`column -t` 需要读完传给它的内容后才能计算列宽，因此对超大文件使用 `-a` 或 `--all` 可能较慢。`tless` 适合 TSV、VCF 和空白字符分隔表格，不是专门的 CSV 查看器。

## nf

`nf` 是 new file 的缩写，用于直接在终端中创建或追加文本文件。

```bash
nf filename
nf -a filename
```

默认模式会覆盖创建文件，并且会在开始输入前清空同名文件。输入单独一行 `EOF` 或 `eof` 时结束。

追加模式：

```bash
nf -a notes.txt
```

## rr

`rr` 是 Run R 的缩写。

```bash
rr
```

等价于：

```bash
Rscript 1.r
```

指定脚本：

```bash
rr analysis.R
```

等价于：

```bash
Rscript analysis.R
```

`1.r` 主要用于一次性临时脚本。如果当前环境没有 `Rscript`，`rr` 会给出明确提示并退出。

## 管理命令

```bash
moyu help
moyu version
moyu update
```

`moyu version` 会读取当前安装目录中的 `VERSION`，显示类似：

```text
MoyuKit 0.1.0
```

`moyu update` 会从配置的服务器地址下载最新版压缩包，在临时目录中完成下载、解压和校验，确认成功后再替换当前用户的安装目录。下载失败、解压失败或 SHA-256 校验失败时，不会破坏现有安装。MoyuKit 不会在打开 Shell 时自动联网检查更新。

## 卸载

在已安装目录中运行：

```bash
bash uninstall.sh
```

卸载脚本会显示即将删除的安装目录，并要求确认。它会删除当前安装目录和 `~/.bashrc` 中的 MoyuKit 固定标记区块，不会删除 `.bashrc` 备份，也不会修改其他配置。

测试脚本使用非交互参数：

```bash
bash uninstall.sh --yes
```

## 开发目录与安装目录

`/data6A/wuying/projects/MoyuKit` 是开发源码目录，不等同于正式安装目录。正式安装目录默认是 `$HOME/.local/share/moyukit`，也可以通过 `--dir` 指定。测试必须使用临时 `HOME`，不要修改真实 `~/.bashrc`。

## Slurm 批处理

Slurm 批处理脚本不一定读取交互式 Bash 的 `~/.bashrc`。正式批处理脚本中建议直接使用原始命令，或显式加载 MoyuKit：

```bash
source "$HOME/.local/share/moyukit/init.sh"
```

如果使用了自定义安装目录，请把路径替换为实际安装目录。

## 已知限制

`nf` 使用简单的逐行输入机制，不处理复杂终端编辑行为。部分终端中退格键可能显示为 `^H`，当前版本不处理该问题。

`tless` 依赖 `column`、`less`、`awk` 等常见命令；查看 `.gz` 文件时需要 `zcat` 或 `gzip`。缺少可选命令时，MoyuKit 只会提示，不会调用包管理器。
