#!/usr/bin/env bash

_moyukit_init() {
    local init_file init_dir bin_dir old_nullglob func_file

    init_file="${1:?}"
    init_dir="$(cd "$(dirname "$init_file")" && pwd -P)" || return 1

    MOYUKIT_HOME="$init_dir"

    if [[ -r "$MOYUKIT_HOME/config.sh" ]]; then
        # shellcheck source=/dev/null
        source "$MOYUKIT_HOME/config.sh"
    fi

    bin_dir="$MOYUKIT_HOME/bin"
    case ":${PATH:-}:" in
        *":$bin_dir:"*) ;;
        *) PATH="$bin_dir${PATH:+:$PATH}" ;;
    esac
    export PATH

    old_nullglob="$(shopt -p nullglob || true)"
    shopt -s nullglob
    for func_file in "$MOYUKIT_HOME"/functions/*.sh; do
        # shellcheck source=/dev/null
        source "$func_file"
    done
    eval "$old_nullglob"
}

_moyukit_init "${BASH_SOURCE[0]}"
unset -f _moyukit_init
