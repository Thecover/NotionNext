#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
MOYUKIT_BEGIN_MARK="# >>> MoyuKit >>>"
MOYUKIT_END_MARK="# <<< MoyuKit <<<"

usage() {
    cat <<'EOF'
用法：
  bash uninstall.sh [--yes] [--dir DIR]
  bash uninstall.sh --help

选项：
  --yes      非交互确认，供测试脚本使用
  --dir DIR  指定要卸载的安装目录，默认使用当前脚本所在目录
EOF
}

fail() {
    echo "uninstall.sh: $*" >&2
    exit 1
}

expand_path() {
    local input="$1"
    local parent base

    case "$input" in
        "~") input="$HOME" ;;
        "~/"*) input="$HOME/${input#~/}" ;;
    esac

    [[ -n "$input" ]] || fail "目录不能为空"
    [[ "$input" != *$'\n'* ]] || fail "目录不能包含换行"

    if [[ "$input" != /* ]]; then
        input="$PWD/$input"
    fi

    parent="$(dirname "$input")"
    base="$(basename "$input")"
    [[ "$base" != "." && "$base" != ".." ]] || fail "目录不能以 . 或 .. 结尾"
    parent="$(cd "$parent" && pwd -P)" || fail "无法访问父目录：$parent"
    printf '%s/%s\n' "$parent" "$base"
}

assert_safe_remove_dir() {
    local dir="$1"

    case "$dir" in
        ""|/|"$HOME"|/usr|/usr/*|/etc|/etc/*|/opt|/opt/*|/bin|/bin/*|/sbin|/sbin/*)
            fail "拒绝删除危险目录：$dir"
            ;;
    esac

    [[ -d "$dir" ]] || fail "安装目录不存在：$dir"
    [[ -r "$dir/init.sh" && -r "$dir/VERSION" ]] || fail "目标目录不像 MoyuKit 安装目录：$dir"
}

remove_bashrc_block() {
    local bashrc="${HOME}/.bashrc"
    local tmp_file

    [[ -f "$bashrc" ]] || return 0
    tmp_file="$(mktemp "${TMPDIR:-/tmp}/moyukit-bashrc.XXXXXX")"

    awk -v begin="$MOYUKIT_BEGIN_MARK" -v end="$MOYUKIT_END_MARK" '
        $0 == begin {skip = 1; next}
        $0 == end {skip = 0; next}
        skip != 1 {print}
    ' "$bashrc" > "$tmp_file"

    if ! cmp -s "$bashrc" "$tmp_file"; then
        mv "$tmp_file" "$bashrc"
    else
        rm -f "$tmp_file"
    fi
}

main() {
    local assume_yes=false
    local install_dir="$SCRIPT_DIR"
    local answer

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --yes)
                assume_yes=true
                shift
                ;;
            --dir)
                [[ $# -ge 2 ]] || fail "--dir 需要参数"
                install_dir="$2"
                shift 2
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                fail "未知参数：$1"
                ;;
        esac
    done

    install_dir="$(expand_path "$install_dir")"
    assert_safe_remove_dir "$install_dir"

    echo "即将删除 MoyuKit 安装目录：$install_dir"

    if [[ "$assume_yes" != true ]]; then
        printf '确认卸载？输入 yes 继续：'
        IFS= read -r answer
        if [[ "$answer" != "yes" ]]; then
            echo "已取消卸载。"
            exit 0
        fi
    fi

    remove_bashrc_block
    rm -rf "$install_dir"

    echo "MoyuKit 已卸载。"
}

main "$@"
