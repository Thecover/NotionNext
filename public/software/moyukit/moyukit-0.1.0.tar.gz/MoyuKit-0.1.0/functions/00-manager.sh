#!/usr/bin/env bash

moyu() {
    local cmd="${1:-help}"

    case "$cmd" in
        help|-h|--help)
            cat <<'EOF'
MoyuKit 管理命令

用法：
  moyu help
  moyu version
  moyu update
EOF
            ;;
        version)
            if [[ -r "${MOYUKIT_HOME:-}/VERSION" ]]; then
                printf 'MoyuKit %s\n' "$(tr -d '[:space:]' < "${MOYUKIT_HOME}/VERSION")"
            else
                echo "moyu: 无法读取 VERSION 文件" >&2
                return 1
            fi
            ;;
        update)
            _moyu_update
            ;;
        *)
            echo "moyu: 未知命令：$cmd" >&2
            echo "请运行：moyu help" >&2
            return 1
            ;;
    esac
}

_moyu_update() {
    local install_dir server_url tmp_dir archive sha_file extract_dir candidate parent backup
    local missing=() dep expected actual

    install_dir="${MOYUKIT_HOME:-}"
    server_url="${MOYUKIT_SERVER_URL:-}"

    if [[ -z "$install_dir" || ! -d "$install_dir" ]]; then
        echo "moyu update: 无法确定当前安装目录" >&2
        return 1
    fi

    if [[ -z "$server_url" ]]; then
        echo "moyu update: 未配置服务器地址，请检查 config.sh 或设置 MOYUKIT_SERVER_URL" >&2
        return 1
    fi
    case "$install_dir" in
        /|/usr|/usr/*|/etc|/etc/*|/opt|/opt/*|/bin|/bin/*|/sbin|/sbin/*)
            echo "moyu update: 拒绝更新系统目录：$install_dir" >&2
            return 1
            ;;
    esac

    for dep in curl tar sha256sum awk; do
        if ! command -v "$dep" >/dev/null 2>&1; then
            missing+=("$dep")
        fi
    done
    if ((${#missing[@]} > 0)); then
        echo "moyu update: 缺少必需命令：${missing[*]}" >&2
        return 1
    fi

    tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/moyukit-update.XXXXXX")" || return 1
    archive="$tmp_dir/latest.tar.gz"
    sha_file="$tmp_dir/latest.tar.gz.sha256"
    extract_dir="$tmp_dir/extract"
    mkdir -p "$extract_dir"

    if ! curl -fsSL "$server_url/latest.tar.gz" -o "$archive"; then
        echo "moyu update: 下载失败：$server_url/latest.tar.gz" >&2
        rm -rf "$tmp_dir"
        return 1
    fi

    if curl -fsSL "$server_url/latest.tar.gz.sha256" -o "$sha_file"; then
        if ! (cd "$tmp_dir" && sha256sum -c "$(basename "$sha_file")" >/dev/null 2>&1); then
            expected="$(awk 'NR == 1 {print $1}' "$sha_file")"
            actual="$(sha256sum "$archive" | awk '{print $1}')"
            if [[ -z "$expected" || "$expected" != "$actual" ]]; then
                echo "moyu update: SHA-256 校验失败" >&2
                rm -rf "$tmp_dir"
                return 1
            fi
        fi
    else
        echo "moyu update: 未找到 SHA-256 文件，跳过校验" >&2
    fi

    if ! tar -xzf "$archive" -C "$extract_dir"; then
        echo "moyu update: 解压失败，现有安装未修改" >&2
        rm -rf "$tmp_dir"
        return 1
    fi

    candidate="$(find "$extract_dir" -mindepth 1 -maxdepth 2 -type f -name init.sh -print -quit)"
    if [[ -z "$candidate" ]]; then
        echo "moyu update: 发布包中未找到 init.sh" >&2
        rm -rf "$tmp_dir"
        return 1
    fi
    candidate="$(cd "$(dirname "$candidate")" && pwd -P)"

    if [[ ! -r "$candidate/VERSION" || ! -d "$candidate/functions" ]]; then
        echo "moyu update: 发布包结构不完整" >&2
        rm -rf "$tmp_dir"
        return 1
    fi
    mkdir -p "$candidate/bin"

    parent="$(dirname "$install_dir")"
    backup="$(mktemp -d "$parent/.moyukit-prev.XXXXXX")" || {
        echo "moyu update: 无法在安装目录旁创建备份目录" >&2
        rm -rf "$tmp_dir"
        return 1
    }
    rmdir "$backup"

    if ! mv "$install_dir" "$backup"; then
        echo "moyu update: 无法暂存现有安装目录" >&2
        rm -rf "$tmp_dir"
        return 1
    fi

    if ! mv "$candidate" "$install_dir"; then
        echo "moyu update: 替换安装目录失败，正在恢复旧版本" >&2
        mkdir -p "$parent"
        mv "$backup" "$install_dir"
        rm -rf "$tmp_dir"
        return 1
    fi

    rm -rf "$backup" "$tmp_dir"

    if [[ -r "$install_dir/init.sh" ]]; then
        # shellcheck source=/dev/null
        source "$install_dir/init.sh"
    fi

    echo "MoyuKit 已更新：$install_dir"
}
