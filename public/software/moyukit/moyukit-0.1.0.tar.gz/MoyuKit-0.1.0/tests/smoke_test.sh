#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd -P)"
TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/moyukit-test.XXXXXX")"

cleanup() {
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT

fail() {
    echo "smoke_test.sh: $*" >&2
    exit 1
}

assert_file() {
    [[ -f "$ROOT_DIR/$1" ]] || fail "缺少文件：$1"
}

assert_dir() {
    [[ -d "$ROOT_DIR/$1" ]] || fail "缺少目录：$1"
}

assert_contains_once() {
    local file="$1"
    local pattern="$2"
    local count

    count="$(grep -F -c "$pattern" "$file" || true)"
    [[ "$count" == "1" ]] || fail "$file 中 $pattern 出现次数不是 1，而是 $count"
}

required_files=(
    README.md
    VERSION
    CHANGELOG.md
    LICENSE
    .gitignore
    .gitattributes
    .editorconfig
    config.sh
    install.sh
    uninstall.sh
    init.sh
    functions/00-manager.sh
    functions/tless.sh
    functions/nf.sh
    functions/rr.sh
    tests/smoke_test.sh
    scripts/build_release.sh
)

for file in "${required_files[@]}"; do
    assert_file "$file"
done

assert_dir functions
assert_dir tests
assert_dir scripts
assert_dir dist

while IFS= read -r shell_file; do
    bash -n "$shell_file"
done < <(find "$ROOT_DIR" -type f -name '*.sh' ! -path "$ROOT_DIR/dist/*" | sort)

(
    export HOME="$TMP_DIR/home-init"
    mkdir -p "$HOME"
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    type tless >/dev/null
    type nf >/dev/null
    type rr >/dev/null
    type moyu >/dev/null
)

(
    export HOME="$TMP_DIR/home-rr"
    mkdir -p "$HOME" "$TMP_DIR/mockbin"
    cat > "$TMP_DIR/mockbin/Rscript" <<'EOS'
#!/usr/bin/env bash
printf '%s\n' "$1"
EOS
    chmod +x "$TMP_DIR/mockbin/Rscript"
    export PATH="$TMP_DIR/mockbin:$PATH"
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    [[ "$(rr)" == "1.r" ]] || fail "rr 默认目标不是 1.r"
    [[ "$(rr analysis.R)" == "analysis.R" ]] || fail "rr 指定脚本失败"
)

(
    export HOME="$TMP_DIR/home-nf"
    mkdir -p "$HOME"
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    printf 'alpha\nEOF\nignored\n' | nf "$TMP_DIR/nf.txt"
    [[ "$(cat "$TMP_DIR/nf.txt")" == "alpha" ]] || fail "nf 覆盖创建失败"
    printf 'beta\neof\nignored\n' | nf -a "$TMP_DIR/nf.txt"
    [[ "$(cat "$TMP_DIR/nf.txt")" == $'alpha\nbeta' ]] || fail "nf 追加失败"
)

(
    export HOME="$TMP_DIR/home-tless"
    mkdir -p "$HOME" "$TMP_DIR/tless-bin"
    cat > "$TMP_DIR/tless-bin/less" <<'EOS'
#!/usr/bin/env bash
if [[ "${1:-}" == "-S" ]]; then
    shift
fi
cat "$@"
EOS
    chmod +x "$TMP_DIR/tless-bin/less"
    export PATH="$TMP_DIR/tless-bin:$PATH"
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    if tless -n abc </dev/null >/dev/null 2>&1; then
        fail "tless 接受了非法 -n 参数"
    fi
    if tless "$TMP_DIR/not-exist.tsv" >/dev/null 2>&1; then
        fail "tless 接受了不存在的文件"
    fi
    {
        echo '##meta'
        echo '#CHROM POS ID'
        for i in $(seq 1 105); do
            printf 'chr1\t%s\tvar%s\n' "$i" "$i"
        done
    } > "$TMP_DIR/tless.tsv"
    tless_output="$(tless "$TMP_DIR/tless.tsv")"
    [[ "$tless_output" != *'##meta'* ]] || fail "tless 默认没有隐藏 ## 元信息"
    [[ "$tless_output" == *'#CHROM'* ]] || fail "tless 没有保留 #CHROM 表头"
    [[ "$tless_output" == *'var99'* ]] || fail "tless 默认没有保留第 100 行非 ## 内容"
    [[ "$tless_output" != *'var100'* ]] || fail "tless 默认超过 100 行非 ## 限制"
)

(
    export HOME="$TMP_DIR/home-install"
    mkdir -p "$HOME"
    printf 'original bashrc\n' > "$HOME/.bashrc"
    bash "$ROOT_DIR/install.sh" --local-source "$ROOT_DIR" >/dev/null
    default_dir="$HOME/.local/share/moyukit"
    [[ -d "$default_dir" ]] || fail "默认安装目录不存在"
    assert_contains_once "$HOME/.bashrc" "# >>> MoyuKit >>>"
    backup_file="$(find "$HOME" -maxdepth 1 -type f -name '.bashrc.moyukit.bak.*' -print -quit)"
    [[ -n "$backup_file" ]] || fail "安装修改 .bashrc 前没有创建备份"
    grep -F 'original bashrc' "$backup_file" >/dev/null || fail ".bashrc 备份内容不正确"
    bash "$ROOT_DIR/install.sh" --local-source "$ROOT_DIR" >/dev/null
    assert_contains_once "$HOME/.bashrc" "# >>> MoyuKit >>>"
)

(
    export HOME="$TMP_DIR/home-custom"
    mkdir -p "$HOME"
    custom_dir="$TMP_DIR/custom moyukit \$PATH"
    bash "$ROOT_DIR/install.sh" --dir "$custom_dir" --local-source "$ROOT_DIR" >/dev/null
    [[ -d "$custom_dir" ]] || fail "自定义安装目录不存在"
    grep -F "$custom_dir/init.sh" "$HOME/.bashrc" >/dev/null || fail ".bashrc 未写入自定义安装目录"
    assert_contains_once "$HOME/.bashrc" "# >>> MoyuKit >>>"
    bash --noprofile --norc -c 'source "$HOME/.bashrc"; type moyu >/dev/null' || fail "自定义安装目录 .bashrc 加载失败"
    bash "$custom_dir/uninstall.sh" --yes >/dev/null
    [[ ! -e "$custom_dir" ]] || fail "卸载未删除测试安装目录"
    if grep -F "# >>> MoyuKit >>>" "$HOME/.bashrc" >/dev/null 2>&1; then
        fail "卸载未删除 .bashrc MoyuKit 区块"
    fi
)

(
    export HOME="$TMP_DIR/home-moyu"
    mkdir -p "$HOME"
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    moyu help | grep -F 'moyu update' >/dev/null || fail "moyu help 输出不完整"
    [[ "$(moyu version)" == "MoyuKit 0.1.0" ]] || fail "moyu version 输出不正确"
    if MOYUKIT_SERVER_URL="" moyu update >/dev/null 2>&1; then
        fail "moyu update 在空服务器地址下不应成功"
    fi
)

(
    export HOME="$TMP_DIR/home-update-fail"
    mkdir -p "$HOME"
    install_dir="$TMP_DIR/update-install"
    server_dir="$TMP_DIR/bad-server"
    mkdir -p "$server_dir"
    bash "$ROOT_DIR/install.sh" --dir "$install_dir" --local-source "$ROOT_DIR" >/dev/null
    printf 'not a tar archive\n' > "$server_dir/latest.tar.gz"
    (cd "$server_dir" && sha256sum latest.tar.gz > latest.tar.gz.sha256)
    # shellcheck source=/dev/null
    source "$install_dir/init.sh"
    if MOYUKIT_SERVER_URL="file://$server_dir" moyu update >/dev/null 2>&1; then
        fail "moyu update 不应接受损坏的发布包"
    fi
    [[ -r "$install_dir/VERSION" ]] || fail "moyu update 失败后破坏了当前安装"
    [[ "$(cat "$install_dir/VERSION")" == "0.1.0" ]] || fail "moyu update 失败后 VERSION 不正确"
)

echo "smoke_test.sh: PASS"
