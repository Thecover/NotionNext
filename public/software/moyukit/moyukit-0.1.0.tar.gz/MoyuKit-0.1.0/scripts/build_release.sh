#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd -P)"
VERSION_FILE="$ROOT_DIR/VERSION"
PROJECT_NAME="MoyuKit"
FORCE=false

usage() {
    cat <<'EOF'
用法：
  bash scripts/build_release.sh [--force]

选项：
  --force    覆盖同版本已有发布包
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --force)
            FORCE=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "build_release.sh: 未知参数：$1" >&2
            exit 1
            ;;
    esac
done

[[ -r "$VERSION_FILE" ]] || {
    echo "build_release.sh: 无法读取 VERSION" >&2
    exit 1
}

VERSION="$(tr -d '[:space:]' < "$VERSION_FILE")"
[[ -n "$VERSION" ]] || {
    echo "build_release.sh: VERSION 为空" >&2
    exit 1
}

DIST_DIR="$ROOT_DIR/dist"
PACKAGE="$DIST_DIR/moyukit-${VERSION}.tar.gz"
CHECKSUM="$DIST_DIR/moyukit-${VERSION}.tar.gz.sha256"
STAGE_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/moyukit-release.XXXXXX")"
STAGE_DIR="$STAGE_ROOT/${PROJECT_NAME}-${VERSION}"

cleanup() {
    rm -rf "$STAGE_ROOT"
}
trap cleanup EXIT

mkdir -p "$DIST_DIR"

if [[ "$FORCE" != true && ( -e "$PACKAGE" || -e "$CHECKSUM" ) ]]; then
    echo "build_release.sh: 发布文件已存在，如需覆盖请使用 --force" >&2
    exit 1
fi

rm -rf "$STAGE_DIR"
mkdir -p "$STAGE_DIR"

tar \
    --exclude='./.git' \
    --exclude='./dist' \
    --exclude='./tmp' \
    --exclude='./tests/tmp' \
    --exclude='*.log' \
    --exclude='*.tmp' \
    --exclude='*.swp' \
    --exclude='*.swo' \
    --exclude='*~' \
    --exclude='.DS_Store' \
    -C "$ROOT_DIR" -cf - . | tar -C "$STAGE_DIR" -xf -

find "$STAGE_DIR" -type f -name '*.sh' -exec chmod 755 {} +

tar -C "$STAGE_ROOT" -czf "$PACKAGE" "${PROJECT_NAME}-${VERSION}"
(cd "$ROOT_DIR" && sha256sum "dist/$(basename "$PACKAGE")" > "$CHECKSUM")
tar -tzf "$PACKAGE" >/dev/null

echo "发布包：$PACKAGE"
echo "校验文件：$CHECKSUM"
