# Changelog

## 0.1.0

- 建立 MoyuKit 项目结构和统一版本号。
- 新增 `tless`、`nf`、`rr` 三个 Bash 快捷函数。
- 新增 `moyu help`、`moyu version`、`moyu update` 管理命令。
- 新增用户级安装、卸载、本地隔离测试和发布包构建脚本。
