#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd -P)"
TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/nodeq-test.XXXXXX")"
NODEQ="$ROOT_DIR/bin/nodeq"
NQ="$ROOT_DIR/bin/nq"

cleanup() {
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT

fail() {
    echo "nodeq_test.sh: $*" >&2
    exit 1
}

assert_contains() {
    local text="$1"
    local needle="$2"
    [[ "$text" == *"$needle"* ]] || fail "输出缺少：$needle"
}

assert_not_contains() {
    local text="$1"
    local needle="$2"
    [[ "$text" != *"$needle"* ]] || fail "输出不应包含：$needle"
}

assert_fails() {
    if "$@" >"$TMP_DIR/fail.out" 2>"$TMP_DIR/fail.err"; then
        fail "命令本应失败：$*"
    fi
}

write_mock_squeue() {
    local dir="$1"
    cat > "$dir/squeue" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
sep=$'\037'
printf '%s\n' "$*" >> "${NODEQ_SQUEUE_LOG:?}"
if [[ "${NODEQ_SQUEUE_FAIL:-}" == "1" ]]; then
    echo "mock squeue failed" >&2
    exit 2
fi
if [[ "${NODEQ_SQUEUE_INVALID_FIELD:-}" == "1" ]]; then
    echo "squeue: error: Invalid job format specification: ReqTRES" >&2
    printf '%s\n' "${sep}${sep}"
    exit 0
fi
if [[ "${NODEQ_SQUEUE_INVALID_USER:-}" == "1" ]]; then
    echo "squeue: error: Invalid user id specified" >&2
    exit 1
fi
case "${NODEQ_FIXTURE:-empty}" in
    empty)
        exit 0
        ;;
    basic)
        printf '1001%salice%sstar2%s8%s153600M%snode02%s%s4815%sResources%s\n' "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep"
        printf '1002%sbob%smerge job%s4%s32000M%snode05%s%s61%sPriority%s\n' "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep"
        printf '1003%scarol%splain%s1%s150000M%s%snode02%s%sReqNodeNotAvail, May be reserved for other job%s\n' "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep"
        printf '1004%sdana%sspecial_name-1.2%s2%sweirdCPU%s(null)%s%s0%s%s\n' "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep"
        ;;
    hostlist)
        printf '2001%seve%sarray%s6%s2048M%snode[01-03]%s%s3600%sPriority%s\n' "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep"
        printf '2002%sfrank%snode010job%s1%s1024M%snode010%s%s120%sResources%s\n' "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep"
        printf '2003%sgina%srepeat%s1%s1048576M%snode[01-03]%s%s1%sPriority%s\n' "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep"
        ;;
    hostfail)
        printf '3001%shank%sbadlist%s2%s150G%snode[01-02]%s%s10%sPriority%s\n' "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep"
        ;;
    unknownmem)
        printf '4001%sivy%smemcpu%s2%s5Gc%snode01%s%s%s%s\n' "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep" "$sep"
        ;;
esac
EOS
    chmod +x "$dir/squeue"
}

write_mock_scontrol() {
    local dir="$1"
    cat > "$dir/scontrol" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$*" >> "${NODEQ_SCONTROL_LOG:?}"
if [[ "${NODEQ_SCONTROL_FAIL:-}" == "1" ]]; then
    echo "bad hostlist" >&2
    exit 1
fi
case "${*: -1}" in
    'node[01-03]')
        printf 'node01\nnode02\nnode03\n'
        ;;
    'node[01-02]')
        printf 'node01\nnode02\n'
        ;;
    node010)
        printf 'node010\n'
        ;;
    *)
        printf '%s\n' "${*: -1}"
        ;;
esac
EOS
    chmod +x "$dir/scontrol"
}

write_mock_column() {
    local dir="$1"
    cat > "$dir/column" <<'EOS'
#!/usr/bin/env bash
cat
EOS
    chmod +x "$dir/column"
}

make_env() {
    local name="$1"
    local dir="$TMP_DIR/$name"
    mkdir -p "$dir"
    write_mock_squeue "$dir"
    write_mock_scontrol "$dir"
    write_mock_column "$dir"
    printf '%s\n' "$dir"
}

run_nodeq() {
    local fixture="$1"
    shift
    local bindir
    bindir="$(make_env "$fixture-$RANDOM")"
    NODEQ_FIXTURE="$fixture" \
    NODEQ_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    NODEQ_SCONTROL_LOG="$TMP_DIR/scontrol.log" \
    PATH="$bindir:$PATH" \
    bash "$NODEQ" "$@"
}

[[ -x "$NODEQ" ]] || fail "nodeq 不可执行"
[[ -e "$NQ" ]] || fail "nq 不存在"
bash -n "$NODEQ"
bash -n "$NQ"

out="$(run_nodeq empty)"
for node in node01 node02 node03 node04 node05 node06; do
    assert_contains "$out" "[$node] 0 个待运行作业"
done
assert_contains "$out" "[未指定节点] 0 个待运行作业"

rm -f "$TMP_DIR/squeue.log" "$TMP_DIR/scontrol.log"
out="$(run_nodeq basic)"
assert_contains "$out" "[node02] 1 个待运行作业"
assert_contains "$out" "1001"
assert_contains "$out" "alice"
assert_contains "$out" "150G"
assert_contains "$out" "01:20:15"
assert_contains "$out" "[node05] 1 个待运行作业"
assert_contains "$out" "1002"
assert_contains "$out" "32000M"
assert_contains "$out" "[未指定节点] 2 个待运行作业"
assert_contains "$out" "1003"
assert_contains "$out" "ReqNodeNotAvail, May be reserved for other job"
assert_contains "$out" "1004"
assert_contains "$out" "150000M"
assert_not_contains "$out" "[node02] 2 个待运行作业"
[[ ! -e "$TMP_DIR/scontrol.log" ]] || fail "简单节点和未指定节点不应调用 scontrol"

out="$(run_nodeq basic node05)"
assert_contains "$out" "[node05] 1 个待运行作业"
assert_contains "$out" "1002"
assert_not_contains "$out" "1001"
assert_not_contains "$out" "[未指定节点]"

rm -f "$TMP_DIR/squeue.log"
out="$(run_nodeq basic -u alice)"
assert_contains "$out" "[node02]"
grep -F -- "-u alice" "$TMP_DIR/squeue.log" >/dev/null || fail "用户筛选未传给 squeue"

rm -f "$TMP_DIR/squeue.log"
out="$(run_nodeq basic node02 --user alice)"
assert_contains "$out" "[node02]"
grep -F -- "-u alice" "$TMP_DIR/squeue.log" >/dev/null || fail "组合筛选未传给 squeue"

rm -f "$TMP_DIR/scontrol.log"
out="$(run_nodeq hostlist)"
assert_contains "$out" "[node01] 2 个待运行作业"
assert_contains "$out" "[node02] 2 个待运行作业"
assert_contains "$out" "[node03] 2 个待运行作业"
assert_contains "$out" "2001"
assert_contains "$out" "2003"
assert_contains "$out" "1T"
assert_contains "$out" "注：明确请求多个节点的同一作业可能在多个节点下重复显示。"
assert_not_contains "$out" "[node01] 3 个待运行作业"
[[ "$(awk 'END {print NR+0}' "$TMP_DIR/scontrol.log")" == "2" ]] || fail "相同 hostlist 未缓存展开结果"

out="$(run_nodeq hostlist node01)"
assert_contains "$out" "[node01] 2 个待运行作业"
assert_contains "$out" "2001"
assert_contains "$out" "2003"
assert_not_contains "$out" "2002"

bindir="$(make_env hostfail)"
rm -f "$TMP_DIR/scontrol.log"
out="$(
    NODEQ_FIXTURE=hostfail \
    NODEQ_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    NODEQ_SCONTROL_LOG="$TMP_DIR/scontrol.log" \
    NODEQ_SCONTROL_FAIL=1 \
    PATH="$bindir:$PATH" \
    bash "$NODEQ" 2>"$TMP_DIR/hostfail.err"
)"
assert_contains "$out" "[无法解析请求节点] 1 个待运行作业"
assert_contains "$(cat "$TMP_DIR/hostfail.err")" "无法展开请求节点"

out="$(run_nodeq unknownmem)"
assert_contains "$out" "5Gc"
assert_contains "$out" "WAIT"
assert_contains "$out" $'\t-\t'

bindir="$(make_env no-column)"
rm -f "$bindir/column"
toolbin="$TMP_DIR/toolbin"
mkdir -p "$toolbin"
ln -s /usr/bin/mktemp "$toolbin/mktemp"
ln -s /usr/bin/rm "$toolbin/rm"
ln -s /usr/bin/bash "$toolbin/bash"
out="$(
    NODEQ_FIXTURE=basic \
    NODEQ_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    NODEQ_SCONTROL_LOG="$TMP_DIR/scontrol.log" \
    PATH="$bindir:$toolbin" \
    /usr/bin/bash "$NODEQ"
)"
assert_contains "$out" $'JOBID\tUSER\tNAME'

bindir="$(make_env invalid-user)"
out="$(
    NODEQ_FIXTURE=empty \
    NODEQ_SQUEUE_INVALID_USER=1 \
    NODEQ_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    NODEQ_SCONTROL_LOG="$TMP_DIR/scontrol.log" \
    PATH="$bindir:$PATH" \
    bash "$NODEQ" -u no_such_user
)"
assert_contains "$out" "[node01] 0 个待运行作业"

bindir="$(make_env fail)"
assert_fails env \
    NODEQ_FIXTURE=empty \
    NODEQ_SQUEUE_FAIL=1 \
    NODEQ_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    NODEQ_SCONTROL_LOG="$TMP_DIR/scontrol.log" \
    PATH="$bindir:$PATH" \
    bash "$NODEQ"

bindir="$(make_env invalid-field)"
assert_fails env \
    NODEQ_FIXTURE=empty \
    NODEQ_SQUEUE_INVALID_FIELD=1 \
    NODEQ_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    NODEQ_SCONTROL_LOG="$TMP_DIR/scontrol.log" \
    PATH="$bindir:$PATH" \
    bash "$NODEQ"

help_out="$(bash "$NODEQ" --help)"
assert_contains "$help_out" "node01"
assert_contains "$help_out" "MEM_REQ"

assert_fails bash "$NODEQ" --unknown
assert_fails bash "$NODEQ" node07
assert_fails bash "$NODEQ" node01 node02
assert_fails bash "$NODEQ" -u
assert_fails bash "$NODEQ" -u alice -u bob

out1="$(run_nodeq basic node02)"
bindir="$(make_env nq-basic)"
out2="$(
    NODEQ_FIXTURE=basic \
    NODEQ_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    NODEQ_SCONTROL_LOG="$TMP_DIR/scontrol.log" \
    PATH="$bindir:$PATH" \
    bash "$NQ" node02
)"
[[ "$out1" == "$out2" ]] || fail "nodeq 与 nq 输出不一致"

while IFS= read -r shell_file; do
    bash -n "$shell_file"
done < <(find "$ROOT_DIR" -type f -name '*.sh' ! -path "$ROOT_DIR/dist/*" | sort)
bash -n "$ROOT_DIR/bin/nodeq"
bash -n "$ROOT_DIR/bin/nq"

echo "nodeq_test.sh: PASS"
