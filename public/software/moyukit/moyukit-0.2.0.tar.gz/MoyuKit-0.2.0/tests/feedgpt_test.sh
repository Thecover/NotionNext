#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd -P)"
TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/feedgpt-test.XXXXXX")"
FEEDGPT="$ROOT_DIR/bin/feedgpt"
FGT="$ROOT_DIR/bin/fgt"

cleanup() {
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT

fail() {
    echo "feedgpt_test.sh: $*" >&2
    exit 1
}

assert_contains() {
    local text="$1"
    local needle="$2"
    [[ "$text" == *"$needle"* ]] || fail "输出缺少：$needle"
}

assert_not_contains() {
    local text="$1"
    local needle="$2"
    [[ "$text" != *"$needle"* ]] || fail "输出不应包含：$needle"
}

assert_fails() {
    if "$@" >"$TMP_DIR/fail.out" 2>"$TMP_DIR/fail.err"; then
        fail "命令本应失败：$*"
    fi
}

[[ -x "$FEEDGPT" ]] || fail "feedgpt 不可执行"
[[ -x "$FGT" ]] || fail "fgt 不可执行"
bash -n "$FEEDGPT"
bash -n "$FGT"

metadata="$TMP_DIR/sample info.tsv"
cat > "$metadata" <<'EOF'
Sample	PigID	Tissue	Stage	Note
S1	1	Blood	D3	NA
S2	1	Liver	D21	.
S3	2	Blood	D3	NULL
S4	3	Brain	D35	N/A
S5	4		D21	emptyTissue
EOF

whitespace="$TMP_DIR/space_table.txt"
cat > "$whitespace" <<'EOF'
Sample Group Value
A control 1
B treated 2
EOF

matrix="$TMP_DIR/count_matrix.txt"
{
    printf 'Gene'
    for i in $(seq 1 15); do
        printf '\tS%s' "$i"
    done
    printf '\n'
    printf 'GeneA'
    for i in $(seq 1 15); do
        printf '\t%s' "$i"
    done
    printf '\n'
    printf 'GeneB'
    for i in $(seq 1 15); do
        printf '\t%s' "$((i * 2))"
    done
    printf '\n'
    printf 'GeneC'
    for i in $(seq 1 15); do
        printf '\t%s' "$((i * 3))"
    done
    printf '\n'
} > "$matrix"

gzip -c "$metadata" > "$TMP_DIR/sample info.tsv.gz"
printf 'not gzip\n' > "$TMP_DIR/bad.gz"
: > "$TMP_DIR/empty.txt"
printf 'A\tB\n' > "$TMP_DIR/header_only.tsv"
printf 'x\n' > "$TMP_DIR/-strange-file.txt"

out="$("$FEEDGPT" "$metadata")"
assert_contains "$out" "自动识别的文件类型：metadata"
assert_contains "$out" "该文件共有 5 列"
assert_contains "$out" "1. Sample"
assert_contains "$out" '```text'
assert_contains "$out" "S1"

out="$("$FEEDGPT" ma "$matrix" -r 2 -c 4)"
assert_contains "$out" "指定的文件类型：matrix"
assert_contains "$out" "该文件共有 16 列"
assert_contains "$out" "前 2 行数据和前 4 列"
assert_contains "$out" "..."
assert_contains "$out" "GeneB"
assert_not_contains "$out" "GeneC"

out="$("$FEEDGPT" "$matrix")"
assert_contains "$out" "自动识别的文件类型：matrix"

out="$("$FEEDGPT" "$whitespace" -s whitespace)"
assert_contains "$out" "自动识别的文件类型：metadata"
assert_contains "$out" "Sample"
assert_contains "$out" "control"

out="$("$FEEDGPT" me "$metadata" -u Stage,Tissue)"
assert_contains "$out" "Stage 列共有 3 个非重复值"
assert_contains "$out" "D3, D21, D35"
assert_contains "$out" "Tissue 列共有 3 个非重复值"
assert_contains "$out" "Blood, Liver, Brain"
assert_not_contains "$out" "emptyTissue 列"

out="$("$FEEDGPT" me "$metadata" --unique Stage --unique Tissue)"
assert_contains "$out" "Stage 列共有 3 个非重复值"
assert_contains "$out" "Tissue 列共有 3 个非重复值"

out="$("$FEEDGPT" me "$metadata" -u 4,3)"
assert_contains "$out" "Stage 列共有 3 个非重复值"
assert_contains "$out" "Tissue 列共有 3 个非重复值"

out="$("$FEEDGPT" me "$metadata" -u Stage -l 2)"
assert_contains "$out" "D3, D21"
assert_contains "$out" "已展示前 2 个，共 3 个"
assert_not_contains "$out" "D35"

out="$("$FEEDGPT" me "$metadata" -u Stage -A)"
assert_contains "$out" "D3, D21, D35"

out="$("$FEEDGPT" me "$TMP_DIR/sample info.tsv.gz" -u Stage)"
assert_contains "$out" "Stage 列共有 3 个非重复值"

out1="$("$FEEDGPT" me "$metadata" -r 1 -c 3)"
out2="$("$FGT" me "$metadata" -r 1 -c 3)"
[[ "$out1" == "$out2" ]] || fail "feedgpt 与 fgt 输出不一致"

out="$("$FEEDGPT" -- "$TMP_DIR/-strange-file.txt")"
assert_contains "$out" "自动识别的文件类型：metadata"

out="$("$FEEDGPT" "$TMP_DIR/header_only.tsv")"
assert_contains "$out" "该文件只有表头"

assert_fails "$FEEDGPT"
assert_fails "$FEEDGPT" "$TMP_DIR/not-exist.tsv"
assert_fails "$FEEDGPT" "$TMP_DIR/empty.txt"
assert_fails "$FEEDGPT" "$metadata" -r nope
assert_fails "$FEEDGPT" "$metadata" -c 0
assert_fails "$FEEDGPT" "$metadata" -l x
assert_fails "$FEEDGPT" "$metadata" -s csv
assert_fails "$FEEDGPT" "$metadata" "$matrix"
assert_fails "$FEEDGPT" me "$metadata" -u NotAColumn
assert_fails "$FEEDGPT" me "$metadata" -u 99
assert_fails "$FEEDGPT" me "$metadata" -u Stage,3
assert_fails "$FEEDGPT" "$TMP_DIR/bad.gz"

help_out="$("$FEEDGPT" --help)"
assert_contains "$help_out" "CSV"
assert_contains "$help_out" ".gz"
assert_contains "$help_out" "首次出现"

echo "feedgpt_test.sh: PASS"
