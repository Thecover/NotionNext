#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd -P)"
TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/moyukit-test.XXXXXX")"
PROJECT_VERSION="$(tr -d '[:space:]' < "$ROOT_DIR/VERSION")"

cleanup() {
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT

fail() {
    echo "smoke_test.sh: $*" >&2
    exit 1
}

assert_file() {
    [[ -f "$ROOT_DIR/$1" ]] || fail "缺少文件：$1"
}

assert_dir() {
    [[ -d "$ROOT_DIR/$1" ]] || fail "缺少目录：$1"
}

assert_contains_once() {
    local file="$1"
    local pattern="$2"
    local count

    count="$(grep -F -c "$pattern" "$file" || true)"
    [[ "$count" == "1" ]] || fail "$file 中 $pattern 出现次数不是 1，而是 $count"
}

new_bash() {
    local home="$1"
    local code="$2"

    HOME="$home" bash --noprofile --norc -c "$code"
}

path_count() {
    local haystack="$1"
    local needle="$2"
    awk -v RS=: -v needle="$needle" '$0 == needle {c++} END {print c+0}' <<< "$haystack"
}

required_files=(
    README.md
    VERSION
    CHANGELOG.md
    LICENSE
    .gitignore
    .gitattributes
    .editorconfig
    config.sh
    install.sh
    uninstall.sh
    init.sh
    bin/feedgpt
    bin/fgt
    bin/nodeq
    bin/nq
    bin/jres
    lib/channel.sh
    functions/00-manager.sh
    functions/mkcd.sh
    functions/tless.sh
    functions/nf.sh
    functions/rr.sh
    tests/smoke_test.sh
    tests/feedgpt_test.sh
    tests/nodeq_test.sh
    tests/jres_test.sh
    scripts/build_release.sh
    scripts/install_dev.sh
    scripts/uninstall_dev.sh
)

for file in "${required_files[@]}"; do
    assert_file "$file"
done

assert_dir functions
assert_dir tests
assert_dir scripts
assert_dir lib
assert_dir dist

while IFS= read -r shell_file; do
    bash -n "$shell_file"
done < <(find "$ROOT_DIR" -type f -name '*.sh' ! -path "$ROOT_DIR/dist/*" | sort)
bash -n "$ROOT_DIR/bin/feedgpt"
bash -n "$ROOT_DIR/bin/fgt"
bash -n "$ROOT_DIR/bin/nodeq"
bash -n "$ROOT_DIR/bin/nq"
bash -n "$ROOT_DIR/bin/jres"

bash "$ROOT_DIR/tests/feedgpt_test.sh"
bash "$ROOT_DIR/tests/nodeq_test.sh"
bash "$ROOT_DIR/tests/jres_test.sh"

(
    export HOME="$TMP_DIR/home-init"
    mkdir -p "$HOME"
    MOYUKIT_CHANNEL=stable
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    type tless >/dev/null
    type nf >/dev/null
    type rr >/dev/null
    type mkcd >/dev/null
    type moyu >/dev/null
    type feedgpt >/dev/null
    type fgt >/dev/null
    command -v nodeq >/dev/null
    command -v nq >/dev/null
    command -v jres >/dev/null
)

(
    export HOME="$TMP_DIR/home-mkcd"
    mkdir -p "$HOME"
    MOYUKIT_CHANNEL=stable
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    start_dir="$PWD"
    target="$TMP_DIR/mkcd space/a/b"
    mkcd "$target"
    [[ "$PWD" == "$target" ]] || fail "mkcd 未进入目标目录"
    cd "$start_dir"
    dash_parent="$TMP_DIR/mkcd-dash-parent"
    mkdir -p "$dash_parent"
    cd "$dash_parent"
    mkcd -- -dash-dir
    [[ "$PWD" == "$dash_parent/-dash-dir" ]] || fail "mkcd 未支持 -- -dash-dir"
    cd "$start_dir"
    if mkcd >/dev/null 2>&1; then
        fail "mkcd 缺少参数时应失败"
    fi
    if mkcd "$TMP_DIR/a" "$TMP_DIR/b" >/dev/null 2>&1; then
        fail "mkcd 多余参数时应失败"
    fi
)

(
    export HOME="$TMP_DIR/home-rr"
    mkdir -p "$HOME" "$TMP_DIR/mockbin"
    cat > "$TMP_DIR/mockbin/Rscript" <<'EOS'
#!/usr/bin/env bash
printf '%s\n' "$1"
EOS
    chmod +x "$TMP_DIR/mockbin/Rscript"
    export PATH="$TMP_DIR/mockbin:$PATH"
    MOYUKIT_CHANNEL=stable
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    [[ "$(rr)" == "1.r" ]] || fail "rr 默认目标不是 1.r"
    [[ "$(rr analysis.R)" == "analysis.R" ]] || fail "rr 指定脚本失败"
)

(
    export HOME="$TMP_DIR/home-nf"
    mkdir -p "$HOME"
    MOYUKIT_CHANNEL=stable
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    printf 'alpha\nEOF\nignored\n' | nf "$TMP_DIR/nf.txt"
    [[ "$(cat "$TMP_DIR/nf.txt")" == "alpha" ]] || fail "nf 覆盖创建失败"
    printf 'beta\neof\nignored\n' | nf -a "$TMP_DIR/nf.txt"
    [[ "$(cat "$TMP_DIR/nf.txt")" == $'alpha\nbeta' ]] || fail "nf 追加失败"
)

(
    export HOME="$TMP_DIR/home-tless"
    mkdir -p "$HOME" "$TMP_DIR/tless-bin"
    cat > "$TMP_DIR/tless-bin/less" <<'EOS'
#!/usr/bin/env bash
if [[ "${1:-}" == "-S" ]]; then
    shift
fi
cat "$@"
EOS
    chmod +x "$TMP_DIR/tless-bin/less"
    export PATH="$TMP_DIR/tless-bin:$PATH"
    MOYUKIT_CHANNEL=stable
    # shellcheck source=/dev/null
    source "$ROOT_DIR/init.sh"
    if tless -n abc </dev/null >/dev/null 2>&1; then
        fail "tless 接受了非法 -n 参数"
    fi
    if tless "$TMP_DIR/not-exist.tsv" >/dev/null 2>&1; then
        fail "tless 接受了不存在的文件"
    fi
    {
        echo '##meta'
        echo '#CHROM POS ID'
        for i in $(seq 1 105); do
            printf 'chr1\t%s\tvar%s\n' "$i" "$i"
        done
    } > "$TMP_DIR/tless.tsv"
    tless_output="$(tless "$TMP_DIR/tless.tsv")"
    [[ "$tless_output" != *'##meta'* ]] || fail "tless 默认没有隐藏 ## 元信息"
    [[ "$tless_output" == *'#CHROM'* ]] || fail "tless 没有保留 #CHROM 表头"
    [[ "$tless_output" == *'var99'* ]] || fail "tless 默认没有保留第 100 行非 ## 内容"
    [[ "$tless_output" != *'var100'* ]] || fail "tless 默认超过 100 行非 ## 限制"
)

(
    export HOME="$TMP_DIR/home-channel"
    mkdir -p "$HOME"
    printf '# original bashrc\n' > "$HOME/.bashrc"

    bash "$ROOT_DIR/install.sh" --local-source "$ROOT_DIR" >/dev/null
    stable_dir="$HOME/.local/share/moyukit"
    dev_dir="$HOME/.local/share/moyukit-dev"

    [[ -d "$stable_dir" ]] || fail "稳定版默认安装目录不存在"
    [[ "$(cat "$HOME/.config/moyukit/channel")" == "stable" ]] || fail "新用户默认通道不是 stable"
    grep -F "stable_home=$stable_dir" "$HOME/.config/moyukit/paths.conf" >/dev/null || fail "paths.conf 未记录稳定版路径"
    grep -F "dev_home=$dev_dir" "$HOME/.config/moyukit/paths.conf" >/dev/null || fail "paths.conf 未记录默认开发版路径"
    assert_contains_once "$HOME/.bashrc" "# >>> MoyuKit >>>"
    grep -F '$HOME/.config/moyukit/loader.sh' "$HOME/.bashrc" >/dev/null || fail ".bashrc 未使用公共 loader"
    backup_file="$(find "$HOME" -maxdepth 1 -type f -name '.bashrc.moyukit.bak.*' -print -quit)"
    [[ -n "$backup_file" ]] || fail "安装修改 .bashrc 前没有创建备份"
    grep -F '# original bashrc' "$backup_file" >/dev/null || fail ".bashrc 备份内容不正确"

    new_bash "$HOME" 'source "$HOME/.bashrc"; [[ "$MOYUKIT_CHANNEL" == stable ]]; [[ "$MOYUKIT_HOME" == "$HOME/.local/share/moyukit" ]]; type moyu >/dev/null; type mkcd >/dev/null; type feedgpt >/dev/null; type fgt >/dev/null; command -v nodeq >/dev/null; command -v nq >/dev/null; command -v jres >/dev/null; feedgpt --help >/dev/null; fgt --help >/dev/null; nodeq --help >/dev/null; nq --help >/dev/null; jres --help >/dev/null'

    bash "$ROOT_DIR/scripts/install_dev.sh" --source "$ROOT_DIR" >/dev/null
    [[ -d "$dev_dir" ]] || fail "开发版默认安装目录不存在"
    [[ "$(cat "$HOME/.config/moyukit/channel")" == "stable" ]] || fail "未 activate 安装开发版却改变了通道"

    bash "$ROOT_DIR/scripts/install_dev.sh" --source "$ROOT_DIR" --activate >/dev/null
    [[ "$(cat "$HOME/.config/moyukit/channel")" == "dev" ]] || fail "--activate 未切换到 dev"
    new_bash "$HOME" "source \"\$HOME/.bashrc\"; [[ \"\$MOYUKIT_CHANNEL\" == dev ]]; [[ \"\$MOYUKIT_HOME\" == \"\$HOME/.local/share/moyukit-dev\" ]]; [[ \"\$(moyu version)\" == \"MoyuKit ${PROJECT_VERSION}-dev (dev)\" ]]"

    dev_shell_path="$(new_bash "$HOME" 'source "$HOME/.bashrc"; printf "%s\n" "$PATH"')"
    [[ "$(path_count "$dev_shell_path" "$stable_dir/bin")" == "0" ]] || fail "dev PATH 包含 stable bin"
    [[ "$(path_count "$dev_shell_path" "$dev_dir/bin")" == "1" ]] || fail "dev PATH 未唯一包含 dev bin"

    if new_bash "$HOME" 'source "$HOME/.bashrc"; moyu update' >/dev/null 2>&1; then
        fail "dev 通道下 moyu update 不应执行线上覆盖"
    fi

    new_bash "$HOME" 'source "$HOME/.bashrc"; moyu channel stable >/dev/null'
    [[ "$(cat "$HOME/.config/moyukit/channel")" == "stable" ]] || fail "切回 stable 失败"
    new_bash "$HOME" 'source "$HOME/.bashrc"; [[ "$MOYUKIT_CHANNEL" == stable ]]; [[ "$MOYUKIT_HOME" == "$HOME/.local/share/moyukit" ]]'

    stable_shell_path="$(new_bash "$HOME" 'source "$HOME/.bashrc"; printf "%s\n" "$PATH"')"
    [[ "$(path_count "$stable_shell_path" "$stable_dir/bin")" == "1" ]] || fail "stable PATH 未唯一包含 stable bin"
    [[ "$(path_count "$stable_shell_path" "$dev_dir/bin")" == "0" ]] || fail "stable PATH 包含 dev bin"

    bash "$ROOT_DIR/install.sh" --local-source "$ROOT_DIR" >/dev/null
    bash "$ROOT_DIR/scripts/install_dev.sh" --source "$ROOT_DIR" >/dev/null
    assert_contains_once "$HOME/.bashrc" "# >>> MoyuKit >>>"

    rm -rf "$dev_dir"
    if new_bash "$HOME" 'source "$HOME/.bashrc"; moyu channel dev' >/dev/null 2>&1; then
        fail "目标 dev 不存在时不应允许切换"
    fi
)

(
    export HOME="$TMP_DIR/home-custom"
    mkdir -p "$HOME"
    stable_custom="$TMP_DIR/custom stable"
    dev_custom="$TMP_DIR/custom dev"

    bash "$ROOT_DIR/install.sh" --dir "$stable_custom" --local-source "$ROOT_DIR" >/dev/null
    bash "$ROOT_DIR/scripts/install_dev.sh" --source "$ROOT_DIR" --dir "$dev_custom" --activate >/dev/null
    grep -F "stable_home=$stable_custom" "$HOME/.config/moyukit/paths.conf" >/dev/null || fail "自定义 stable 路径未记录"
    grep -F "dev_home=$dev_custom" "$HOME/.config/moyukit/paths.conf" >/dev/null || fail "自定义 dev 路径未记录"
    new_bash "$HOME" 'source "$HOME/.bashrc"; [[ "$MOYUKIT_CHANNEL" == dev ]]; [[ "$MOYUKIT_HOME" == "'"$dev_custom"'" ]]'
    new_bash "$HOME" 'source "$HOME/.bashrc"; moyu channel stable >/dev/null'
    new_bash "$HOME" 'source "$HOME/.bashrc"; [[ "$MOYUKIT_CHANNEL" == stable ]]; [[ "$MOYUKIT_HOME" == "'"$stable_custom"'" ]]'
)

(
    export HOME="$TMP_DIR/home-uninstall"
    mkdir -p "$HOME"
    bash "$ROOT_DIR/install.sh" --local-source "$ROOT_DIR" >/dev/null
    bash "$ROOT_DIR/scripts/install_dev.sh" --source "$ROOT_DIR" --activate >/dev/null
    stable_dir="$HOME/.local/share/moyukit"
    dev_dir="$HOME/.local/share/moyukit-dev"

    bash "$dev_dir/uninstall.sh" --yes >/dev/null
    [[ ! -e "$dev_dir" ]] || fail "卸载开发版未删除 dev 目录"
    [[ -d "$stable_dir" ]] || fail "卸载开发版误删 stable"
    [[ "$(cat "$HOME/.config/moyukit/channel")" == "stable" ]] || fail "卸载当前 dev 后未切换到 stable"
    assert_contains_once "$HOME/.bashrc" "# >>> MoyuKit >>>"

    bash "$stable_dir/uninstall.sh" --yes >/dev/null
    [[ ! -e "$stable_dir" ]] || fail "卸载稳定版未删除 stable 目录"
    [[ ! -e "$HOME/.config/moyukit/loader.sh" ]] || fail "两套卸载后未清理 loader"
    [[ ! -e "$HOME/.config/moyukit/channel" ]] || fail "两套卸载后未清理 channel"
    if grep -F "# >>> MoyuKit >>>" "$HOME/.bashrc" >/dev/null 2>&1; then
        fail "两套卸载后未删除 .bashrc MoyuKit 区块"
    fi
)

(
    export HOME="$TMP_DIR/home-uninstall-stable-only"
    mkdir -p "$HOME"
    bash "$ROOT_DIR/install.sh" --local-source "$ROOT_DIR" >/dev/null
    bash "$ROOT_DIR/scripts/install_dev.sh" --source "$ROOT_DIR" --activate >/dev/null
    stable_dir="$HOME/.local/share/moyukit"
    dev_dir="$HOME/.local/share/moyukit-dev"

    bash "$stable_dir/uninstall.sh" --yes >/dev/null
    [[ ! -e "$stable_dir" ]] || fail "卸载稳定版未删除 stable"
    [[ -d "$dev_dir" ]] || fail "卸载稳定版误删 dev"
    [[ "$(cat "$HOME/.config/moyukit/channel")" == "dev" ]] || fail "卸载非活动 stable 不应改变 dev 通道"
)

echo "smoke_test.sh: PASS"
