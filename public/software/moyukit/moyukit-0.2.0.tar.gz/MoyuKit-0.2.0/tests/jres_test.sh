#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd -P)"
TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/jres-test.XXXXXX")"
JRES="$ROOT_DIR/bin/jres"

cleanup() {
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT

fail() {
    echo "jres_test.sh: $*" >&2
    exit 1
}

assert_contains() {
    local text="$1"
    local needle="$2"
    [[ "$text" == *"$needle"* ]] || fail "输出缺少：$needle"
}

assert_not_contains() {
    local text="$1"
    local needle="$2"
    [[ "$text" != *"$needle"* ]] || fail "输出不应包含：$needle"
}

assert_fails() {
    if "$@" >"$TMP_DIR/fail.out" 2>"$TMP_DIR/fail.err"; then
        fail "命令本应失败：$*"
    fi
}

reset_logs() {
    rm -f "$TMP_DIR/sacct.log" "$TMP_DIR/sstat.log" "$TMP_DIR/squeue.log" "$TMP_DIR/id.log" "$TMP_DIR/date.log"
}

log_lines() {
    local file="$1"
    if [[ -f "$file" ]]; then
        wc -l < "$file" | tr -d '[:space:]'
    else
        printf '0'
    fi
}

write_mock_sacct() {
    local dir="$1"
    cat > "$dir/sacct" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$*" >> "${JRES_SACCT_LOG:?}"
if [[ "${JRES_SACCT_FAIL:-}" == "1" ]]; then
    echo "mock sacct failed" >&2
    exit 2
fi
job=""
user=""
start=""
format=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        -j)
            job="${2:-}"
            shift 2
            ;;
        -u)
            user="${2:-}"
            shift 2
            ;;
        -S)
            start="${2:-}"
            shift 2
            ;;
        --format=*)
            format="${1#--format=}"
            shift
            ;;
        --format)
            format="${2:-}"
            shift 2
            ;;
        *)
            shift
            ;;
    esac
done

candidate_rows() {
    case "${JRES_CANDIDATE_SET:-default}" in
        empty)
            return
            ;;
        onlyrun)
            echo '208|208|onlyrun|RUNNING|Unknown|mockuser'
            return
            ;;
        onlypend)
            echo '209|209|onlypend|PENDING|Unknown|mockuser'
            return
            ;;
        latest_tie)
            echo '300|300|latestold|COMPLETED|2026-07-29T14:00:00|mockuser'
            echo '301|301|latestnew|FAILED|2026-07-29T14:00:00|mockuser'
            echo '400|400|otheruserjob|COMPLETED|2026-07-29T18:00:00|otheruser'
            return
            ;;
    esac

    echo '201|201|test|COMPLETED|2026-07-29T10:00:00|mockuser'
    echo '199|199|test|FAILED|2026-07-29T12:00:00|mockuser'
    echo '250|250|test|RUNNING|2026-07-29T15:00:00|mockuser'
    echo '251|251|test|PENDING|Unknown|mockuser'
    echo '199.batch|199.batch|batch|FAILED|2026-07-29T12:00:00|mockuser'
    echo '199.extern|199.extern|extern|FAILED|2026-07-29T12:00:00|mockuser'
    echo '199.0|199.0|step0|FAILED|2026-07-29T12:00:00|mockuser'
    echo '202|202|test1|COMPLETED|2026-07-29T16:00:00|mockuser'
    echo '203|203|mytest|COMPLETED|2026-07-29T17:00:00|mockuser'
    echo '204|204|Test|COMPLETED|2026-07-29T18:00:00|mockuser'
    echo '205|205|my test|COMPLETED|2026-07-29T09:00:00|mockuser'
    echo '206|206|a.b[1]*|COMPLETED|2026-07-29T08:00:00|mockuser'
    echo '244|244|24455|COMPLETED|2026-07-29T07:00:00|mockuser'
    echo '246|246|-strange-name|COMPLETED|2026-07-29T06:00:00|mockuser'
    echo '210|210|badend|COMPLETED|Unknown|mockuser'
    echo '211|211|badend|FAILED|not-a-date|mockuser'
    echo '212|212|cancelname|CANCELLED by 1010|2026-07-29T05:00:00|mockuser'
    echo '213|213|timeoutname|TIMEOUT+|2026-07-29T05:01:00|mockuser'
    echo '214|214|oomname|OUT_OF_MEMORY|2026-07-29T05:02:00|mockuser'
    echo '215|215|nodefailname|NODE_FAIL|2026-07-29T05:03:00|mockuser'
    echo '216|216|preemptname|PREEMPTED|2026-07-29T05:04:00|mockuser'
    echo '217|217|bootname|BOOT_FAIL|2026-07-29T05:05:00|mockuser'
    echo '218|218|deadlinename|DEADLINE|2026-07-29T05:06:00|mockuser'
    echo '219|219|revokedname|REVOKED|2026-07-29T05:07:00|mockuser'
    echo '220|220|specialname|SPECIAL_EXIT|2026-07-29T05:08:00|mockuser'
    echo '221|221|sameend|COMPLETED|2026-07-29T06:00:00|mockuser'
    echo '222|222|sameend|COMPLETED|2026-07-29T06:00:00|mockuser'
    echo '12345_7|223|arrayjob|COMPLETED|2026-07-29T08:30:00|mockuser'
    echo '12345_7.batch|223.batch|batch|COMPLETED|2026-07-29T08:30:00|mockuser'
    echo '224+1|224|heterjob|COMPLETED|2026-07-29T08:31:00|mockuser'
    echo '400|400|otheruserjob|COMPLETED|2026-07-29T19:00:00|otheruser'
}

detail_job() {
    local id="$1"
    local raw="$2"
    local name="$3"
    local state="$4"
    local exitcode="${5:-0:0}"
    echo "$id|$raw|$name|$state|$exitcode|00:10:00|600|node01|1|1|2|2|1024M|billing=2,cpu=2,mem=1024M,node=1|billing=2,cpu=2,mem=1024M,node=1|1200|00:10:00||||"
    echo "$id.batch|$raw.batch|batch|$state|$exitcode|00:10:00|600|node01|1|1|2|2||||1200|00:10:00|512M||"
}

if [[ -z "$job" ]]; then
    if [[ "${JRES_CANDIDATE_FAIL:-}" == "1" ]]; then
        echo "mock candidate failed" >&2
        exit 3
    fi
    [[ "$user" == "mockuser" ]] || exit 0
    [[ "$start" == "2026-04-30" ]] || exit 0
    [[ "$format" == *JobID* && "$format" == *End* && "$format" == *User* ]] || exit 0
    candidate_rows
    exit 0
fi

case "$job" in
    100)
        echo '100|100|okjob|COMPLETED|0:0|04:03:22|14602|node02|1|1|2|2|102400M|billing=2,cpu=2,mem=102400M,node=1|billing=2,cpu=2,mem=102400M,node=1|29204|07:34:14||||'
        echo '100.batch|100.batch|batch|COMPLETED|0:0|04:03:22|14602|node02|1|1|2|2||||29204|07:34:14|29678.62M|123M|cpu=01:54:18,mem=29678.62M'
        ;;
    101)
        echo '101|101|running|RUNNING|0:0|01:22:18|4938|node03|1|1|8|8|153600M|billing=8,cpu=8,mem=153600M,node=1|billing=8,cpu=8,mem=153600M,node=1|39504|00:00:00||||'
        echo '101.batch|101.batch|batch|RUNNING|0:0|01:22:18|4938|node03|1|1|8|8||||39504|00:00:00||||'
        ;;
    102)
        echo '102|102|pending|PENDING|0:0|00:00:00|0|None assigned|1||4|0|102400M|billing=4,cpu=4,mem=102400M,node=1||0|00:00:00||||'
        ;;
    103)
        echo '103|103|failed|FAILED|1:0|00:00:09|9|node02|1|1|4|4|102400M|billing=4,cpu=4,mem=102400M,node=1|billing=4,cpu=4,mem=102400M,node=1|36|00:05.634||||'
        echo '103.batch|103.batch|batch|FAILED|1:0|00:00:09|9|node02|1|1|4|4||||36|00:05.634|4.92M||'
        ;;
    104)
        echo '104|104|cancelled|CANCELLED by 1010|0:9|00:00:35|35|node02|1|1|4|4|307200M|billing=4,cpu=4,mem=307200M,node=1|billing=4,cpu=4,mem=307200M,node=1|140|00:00.004||||'
        echo '104.batch|104.batch|batch|CANCELLED|0:15|00:00:36|36|node02|1|1|4|4||||144|00:00.004|14725.32M||'
        ;;
    105)
        echo '105|105|timeout|TIMEOUT|1:9|1-00:00:00|86400|node04|1|1|4|4||billing=4,cpu=4,mem=4096M,node=1|billing=4,cpu=4,mem=4096M,node=1|345600|1-00:00:00||||'
        echo '105.batch|105.batch|batch|TIMEOUT|1:9|1-00:00:00|86400|node04|1|1|4|4||||345600|1-00:00:00|1048576M||'
        ;;
    106)
        echo '106|106|oom|OUT_OF_MEMORY|0:125|2-23:48:56|258536|node02|1|1|4|4|102400M|billing=4,cpu=4,mem=102400M,node=1|billing=4,cpu=4,mem=102400M,node=1|1034144|11-13:51:19||||'
        echo '106.batch|106.batch|batch|OUT_OF_MEMORY|0:125|2-23:48:56|258536|node02|1|1|4|4||||1034144|11-13:51:19|744512.41M||'
        ;;
    107)
        echo '107|107|nodefail|NODE_FAIL|0:0|00:10:00|600|node05|1|1|2|2|2048M|billing=2,cpu=2,mem=2048M,node=1|billing=2,cpu=2,mem=2048M,node=1|1200|00:01:00||||'
        echo '107.batch|107.batch|batch|NODE_FAIL|0:0|00:10:00|600|node05|1|1|2|2||||1200|00:01:00|1024M||'
        ;;
    108)
        echo '108|108|mystery|WEIRD_STATE|0:0|00:01:00|60|node01|1|1|1|1|1024M|billing=1,cpu=1,mem=1024M,node=1|billing=1,cpu=1,mem=1024M,node=1|60|00:00:30||||'
        echo '108.batch|108.batch|batch|WEIRD_STATE|0:0|00:01:00|60|node01|1|1|1|1||||60|00:00:30|512M||'
        ;;
    109)
        echo '109|109|allocmem|COMPLETED|0:0|00:10:00|600|node01|1|1|2|2|||billing=2,cpu=2,mem=2048M,node=1|1200|00:10:00||||'
        echo '109.batch|109.batch|batch|COMPLETED|0:0|00:10:00|600|node01|1|1|2|2||||1200|00:10:00|1024M||'
        ;;
    110)
        echo '110|110|reqmem|COMPLETED|0:0|00:10:00|600|node01|1|1|2|2|4096M|||1200|00:10:00||||'
        echo '110.batch|110.batch|batch|COMPLETED|0:0|00:10:00|600|node01|1|1|2|2||||1200|00:10:00|2048M||'
        ;;
    111)
        echo '111|111|nostep|COMPLETED|0:0|00:01:00|60|node01|1|1|1|1|1024M|billing=1,cpu=1,mem=1024M,node=1|billing=1,cpu=1,mem=1024M,node=1|60|00:00:30||||'
        ;;
    112)
        echo '112|112|fallback|COMPLETED|0:0|00:01:00|60|node01|1|1|1|1|1024M|billing=1,cpu=1,mem=1024M,node=1|billing=1,cpu=1,mem=1024M,node=1|60|00:00:30||||'
        echo '112.extern|112.extern|extern|COMPLETED|0:0|00:01:00|60|node01|1|1|1|1||||60|00:00:00|900M||'
        echo '112.0|112.0|step0|COMPLETED|0:0|00:01:00|60|node01|1|1|1|1||||60|00:00:30|700M||'
        ;;
    113)
        echo '113|113|multi|COMPLETED|0:0|00:10:00|600|node01|1|4|4|4|4096M|billing=4,cpu=4,mem=4096M,node=1|billing=4,cpu=4,mem=4096M,node=1|2400|00:20:00||||'
        echo '113.batch|113.batch|batch|COMPLETED|0:0|00:10:00|600|node01|1|4|4|4||||2400|00:20:00|1024M||'
        ;;
    114)
        echo '114_1|114_1|array1|COMPLETED|0:0|00:01:00|60|node01|1|1|1|1|1024M|billing=1,cpu=1,mem=1024M,node=1|billing=1,cpu=1,mem=1024M,node=1|60|00:00:30||||'
        echo '114_2|114_2|array2|COMPLETED|0:0|00:01:00|60|node01|1|1|1|1|1024M|billing=1,cpu=1,mem=1024M,node=1|billing=1,cpu=1,mem=1024M,node=1|60|00:00:30||||'
        ;;
    115)
        exit 0
        ;;
    116)
        echo '116.batch|116.batch|batch|COMPLETED|0:0|00:01:00|60|node01|1|1|1|1||||60|00:00:30|512M||'
        ;;
    117)
        echo '117|117|delay|COMPLETED|0:0|00:01:00|60|node01|1|1|1|1|1024M|billing=1,cpu=1,mem=1024M,node=1|billing=1,cpu=1,mem=1024M,node=1|60|||||'
        echo '117.batch|117.batch|batch|COMPLETED|0:0|00:01:00|60|node01|1|1|1|1||||60||||'
        ;;
    118)
        echo '118|118|badtime|COMPLETED|0:0|bad|bad|node01|1|1|1|1|1024M|billing=1,cpu=1,mem=1024M,node=1|billing=1,cpu=1,mem=1024M,node=1|bad|badtime||||'
        echo '118.batch|118.batch|batch|COMPLETED|0:0|bad|bad|node01|1|1|1|1||||bad|badtime|512M||'
        ;;
    199) detail_job 199 199 test FAILED 1:0 ;;
    201) detail_job 201 201 test COMPLETED 0:0 ;;
    205) detail_job 205 205 'my test' COMPLETED 0:0 ;;
    206) detail_job 206 206 'a.b[1]*' COMPLETED 0:0 ;;
    212) detail_job 212 212 cancelname 'CANCELLED by 1010' 0:9 ;;
    213) detail_job 213 213 timeoutname 'TIMEOUT+' 1:9 ;;
    214) detail_job 214 214 oomname OUT_OF_MEMORY 0:125 ;;
    215) detail_job 215 215 nodefailname NODE_FAIL 0:0 ;;
    216) detail_job 216 216 preemptname PREEMPTED 0:0 ;;
    217) detail_job 217 217 bootname BOOT_FAIL 1:0 ;;
    218) detail_job 218 218 deadlinename DEADLINE 1:0 ;;
    219) detail_job 219 219 revokedname REVOKED 0:0 ;;
    220) detail_job 220 220 specialname SPECIAL_EXIT 1:0 ;;
    222) detail_job 222 222 sameend COMPLETED 0:0 ;;
    244) detail_job 244 244 24455 COMPLETED 0:0 ;;
    246) detail_job 246 246 -strange-name COMPLETED 0:0 ;;
    300) detail_job 300 300 latestold COMPLETED 0:0 ;;
    301) detail_job 301 301 latestnew FAILED 1:0 ;;
    12345_7) detail_job 12345_7 223 arrayjob COMPLETED 0:0 ;;
    224+1) detail_job 224+1 224 heterjob COMPLETED 0:0 ;;
    *)
        exit 0
        ;;
esac
EOS
    chmod +x "$dir/sacct"
}

write_mock_sstat() {
    local dir="$1"
    cat > "$dir/sstat" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$*" >> "${JRES_SSTAT_LOG:?}"
if [[ "${JRES_SSTAT_FAIL:-}" == "1" ]]; then
    echo "couldn't get steps" >&2
    exit 1
fi
job=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        -j)
            job="${2:-}"
            shift 2
            ;;
        *)
            shift
            ;;
    esac
done
case "$job" in
    101)
        echo '101.batch|43622400K|123K|cpu=00:40:17,mem=43622400K'
        ;;
esac
EOS
    chmod +x "$dir/sstat"
}

write_mock_squeue() {
    local dir="$1"
    cat > "$dir/squeue" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$*" >> "${JRES_SQUEUE_LOG:?}"
if [[ "${JRES_SQUEUE_FAIL:-}" == "1" ]]; then
    echo "mock squeue failed" >&2
    exit 1
fi
sep=$'\037'
echo "102${sep}(Priority)${sep}node02${sep}"
EOS
    chmod +x "$dir/squeue"
}

write_mock_id() {
    local dir="$1"
    cat > "$dir/id" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$*" >> "${JRES_ID_LOG:?}"
if [[ "${1:-}" == "-un" ]]; then
    echo "mockuser"
    exit 0
fi
/usr/bin/id "$@"
EOS
    chmod +x "$dir/id"
}

write_mock_date() {
    local dir="$1"
    cat > "$dir/date" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$*" >> "${JRES_DATE_LOG:?}"
if [[ "${1:-}" == "-d" && "${2:-}" == "90 days ago" && "${3:-}" == "+%Y-%m-%d" ]]; then
    echo "2026-04-30"
    exit 0
fi
if [[ "${1:-}" == "-d" && "${3:-}" == "+%s" ]]; then
    /usr/bin/date "$@"
    exit $?
fi
/usr/bin/date "$@"
EOS
    chmod +x "$dir/date"
}

make_env() {
    local name="$1"
    local dir="$TMP_DIR/$name"
    mkdir -p "$dir"
    write_mock_sacct "$dir"
    write_mock_sstat "$dir"
    write_mock_squeue "$dir"
    write_mock_id "$dir"
    write_mock_date "$dir"
    printf '%s\n' "$dir"
}

add_core_tools() {
    local dir="$1"
    local tool path
    for tool in bash mktemp rm awk cat; do
        path="$(command -v "$tool")" || fail "测试环境缺少基础命令：$tool"
        [[ -e "$dir/$tool" ]] || ln -s "$path" "$dir/$tool"
    done
}

run_jres() {
    local bindir
    bindir="$(make_env "env-$RANDOM")"
    JRES_SACCT_LOG="$TMP_DIR/sacct.log" \
    JRES_SSTAT_LOG="$TMP_DIR/sstat.log" \
    JRES_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    JRES_ID_LOG="$TMP_DIR/id.log" \
    JRES_DATE_LOG="$TMP_DIR/date.log" \
    JRES_CANDIDATE_SET="${JRES_CANDIDATE_SET:-}" \
    JRES_CANDIDATE_FAIL="${JRES_CANDIDATE_FAIL:-}" \
    PATH="$bindir:$PATH" \
    bash "$JRES" "$@"
}

[[ -x "$JRES" ]] || fail "jres 不可执行"
bash -n "$JRES"

reset_logs
out="$(run_jres 100)"
assert_not_contains "$out" "已选择当前用户最近结束的作业"
assert_not_contains "$out" "按作业名精确匹配"
[[ "$(log_lines "$TMP_DIR/sacct.log")" == "1" ]] || fail "直接 Job ID 模式应只执行一次详细 sacct"
[[ "$(log_lines "$TMP_DIR/id.log")" == "0" ]] || fail "直接 Job ID 模式不应调用 id -un"
[[ "$(log_lines "$TMP_DIR/date.log")" == "0" ]] || fail "直接 Job ID 模式不应计算 90 天范围"
assert_contains "$(sed -n '1p' "$TMP_DIR/sacct.log")" "-j 100"
assert_not_contains "$(sed -n '1p' "$TMP_DIR/sacct.log")" "-u mockuser"
assert_not_contains "$(sed -n '1p' "$TMP_DIR/sacct.log")" "-S 2026-04-30"
assert_contains "$out" "状态：COMPLETED（已完成）"
assert_contains "$out" "退出状态：0:0（正常退出）"
assert_contains "$out" "平均等效使用：1.87 核"
assert_contains "$out" "利用率：93.3%"
assert_contains "$out" "申请：100G"
assert_contains "$out" "Slurm 观测峰值：29.0G"
assert_contains "$out" "峰值/申请：29.0%"
assert_not_contains "$out" "UserCPU"
assert_not_contains "$out" "SystemCPU"
assert_not_contains "$out" "AveRSS"
assert_not_contains "$out" "MaxDiskRead"
assert_not_contains "$out" "MaxDiskWrite"
assert_not_contains "$out" "billing=2,cpu=2"

reset_logs
out="$(JRES_CANDIDATE_SET=latest_tie run_jres)"
assert_contains "$out" "已选择当前用户最近结束的作业："
assert_contains "$out" "JobID：301"
assert_contains "$out" "作业名：latestnew"
assert_contains "$out" "结束时间：2026-07-29T14:00:00"
assert_contains "$out" "作业：301  latestnew"
assert_contains "$out" "状态：FAILED（失败）"
[[ "$(log_lines "$TMP_DIR/sacct.log")" == "2" ]] || fail "无参数模式应执行一次候选 sacct 和一次详细 sacct"
first_sacct="$(sed -n '1p' "$TMP_DIR/sacct.log")"
second_sacct="$(sed -n '2p' "$TMP_DIR/sacct.log")"
assert_contains "$first_sacct" "-u mockuser"
assert_contains "$first_sacct" "-S 2026-04-30"
assert_contains "$first_sacct" "JobName%160"
assert_not_contains "$first_sacct" "MaxRSS"
assert_not_contains "$first_sacct" "TotalCPU"
assert_not_contains "$first_sacct" "TRESUsageInMax"
assert_contains "$second_sacct" "-j 301"
assert_contains "$(cat "$TMP_DIR/id.log")" "-un"
assert_contains "$(cat "$TMP_DIR/date.log")" "90 days ago"

reset_logs
out="$(run_jres test)"
assert_contains "$out" "按作业名精确匹配：test"
assert_contains "$out" "找到 2 个已结束的同名作业，已选择最近结束的一个："
assert_contains "$out" "JobID：199"
assert_contains "$out" "结束时间：2026-07-29T12:00:00"
assert_contains "$out" "作业：199  test"
assert_contains "$out" "状态：FAILED（失败）"
assert_not_contains "$out" "JobID：201"
assert_not_contains "$out" "JobID：202"
assert_not_contains "$out" "JobID：203"
assert_not_contains "$out" "JobID：204"
[[ "$(log_lines "$TMP_DIR/sacct.log")" == "2" ]] || fail "作业名模式应执行一次候选 sacct 和一次详细 sacct"
[[ "$(log_lines "$TMP_DIR/sstat.log")" == "0" ]] || fail "候选查询不应调用 sstat"
[[ "$(log_lines "$TMP_DIR/squeue.log")" == "0" ]] || fail "已结束名称模式不应调用 squeue"

out="$(run_jres sameend)"
assert_contains "$out" "JobID：222"
assert_contains "$out" "作业：222  sameend"

out="$(run_jres 'my test')"
assert_contains "$out" "按作业名精确匹配：my test"
assert_contains "$out" "JobID：205"

out="$(run_jres 'a.b[1]*')"
assert_contains "$out" "按作业名精确匹配：a.b[1]*"
assert_contains "$out" "JobID：206"

out="$(run_jres --name 24455)"
assert_contains "$out" "按作业名精确匹配：24455"
assert_contains "$out" "JobID：244"
assert_contains "$out" "作业：244  24455"

out="$(run_jres -- -strange-name)"
assert_contains "$out" "按作业名精确匹配：-strange-name"
assert_contains "$out" "JobID：246"

out="$(run_jres --name=-strange-name)"
assert_contains "$out" "JobID：246"

reset_logs
out="$(run_jres 12345_7)"
assert_contains "$out" "作业：12345_7  arrayjob"
[[ "$(log_lines "$TMP_DIR/sacct.log")" == "1" ]] || fail "数组元素 Job ID 应直接查询，不走候选"

reset_logs
out="$(run_jres 224+1)"
assert_contains "$out" "作业：224+1  heterjob"
[[ "$(log_lines "$TMP_DIR/sacct.log")" == "1" ]] || fail "异构 Job ID 应直接查询，不走候选"

for name in cancelname timeoutname oomname nodefailname preemptname bootname deadlinename revokedname specialname; do
    out="$(run_jres "$name")"
    assert_contains "$out" "按作业名精确匹配：$name"
    assert_contains "$out" "作业："
done

out="$(run_jres timeoutname)"
assert_contains "$out" "状态：TIMEOUT+（超时）"

reset_logs
if JRES_CANDIDATE_SET=empty run_jres >"$TMP_DIR/latest-empty.out" 2>"$TMP_DIR/latest-empty.err"; then
    fail "无参数无候选时应失败"
fi
assert_contains "$(cat "$TMP_DIR/latest-empty.err")" "最近 90 天没有找到当前用户已结束的作业"

if run_jres absent >"$TMP_DIR/name-missing.out" 2>"$TMP_DIR/name-missing.err"; then
    fail "指定名称无候选时应失败"
fi
assert_contains "$(cat "$TMP_DIR/name-missing.err")" "最近 90 天没有找到当前用户名称完全匹配 “absent” 的已结束作业"

if JRES_CANDIDATE_SET=onlyrun run_jres onlyrun >"$TMP_DIR/onlyrun.out" 2>"$TMP_DIR/onlyrun.err"; then
    fail "只有运行中同名作业时应失败"
fi
assert_contains "$(cat "$TMP_DIR/onlyrun.err")" "尚未找到已经结束的同名作业"

if JRES_CANDIDATE_SET=onlypend run_jres onlypend >"$TMP_DIR/onlypend.out" 2>"$TMP_DIR/onlypend.err"; then
    fail "只有排队中同名作业时应失败"
fi
assert_contains "$(cat "$TMP_DIR/onlypend.err")" "运行中或排队中的作业不会参与按名称自动选择"

if run_jres badend >"$TMP_DIR/badend.out" 2>"$TMP_DIR/badend.err"; then
    fail "End 为空或无法解析时不应选择候选"
fi
assert_contains "$(cat "$TMP_DIR/badend.err")" "End 时间为空或无法解析"

if JRES_CANDIDATE_FAIL=1 run_jres test >"$TMP_DIR/candidate-fail.out" 2>"$TMP_DIR/candidate-fail.err"; then
    fail "候选 sacct 失败时应返回非零"
fi
assert_contains "$(cat "$TMP_DIR/candidate-fail.err")" "sacct 候选查询失败"

rm -f "$TMP_DIR/sstat.log"
out="$(run_jres 101)"
assert_contains "$out" "状态：RUNNING（运行中）"
assert_contains "$out" "退出状态：尚未结束"
assert_contains "$out" "实际利用率：运行中暂无法可靠计算"
assert_contains "$out" "截至目前观测峰值：41.6G"
assert_contains "$out" "峰值/申请：27.7%"
grep -F -- "-a" "$TMP_DIR/sstat.log" >/dev/null || fail "运行中作业未使用 sstat -a"

rm -f "$TMP_DIR/squeue.log"
out="$(run_jres 102)"
assert_contains "$out" "状态：PENDING（排队中）"
assert_contains "$out" "原因：(Priority)"
assert_contains "$out" "请求节点：node02"
assert_contains "$out" "退出状态：尚未结束"
assert_contains "$out" "资源使用：作业尚未开始运行"
grep -F -- "-j 102" "$TMP_DIR/squeue.log" >/dev/null || fail "PENDING 作业未用 squeue 补充信息"

out="$(run_jres 103)"
assert_contains "$out" "状态：FAILED（失败）"
assert_contains "$out" "退出状态：1:0（程序返回非零退出码 1）"
assert_contains "$out" "利用率：15.7%"

out="$(run_jres 104)"
assert_contains "$out" "状态：CANCELLED by 1010（已取消）"
assert_contains "$out" "退出状态：0:9（收到终止信号 9）"

out="$(run_jres 105)"
assert_contains "$out" "状态：TIMEOUT（超时）"
assert_contains "$out" "退出状态：1:9（退出码 1，并收到终止信号 9）"
assert_contains "$out" "Slurm 观测峰值：1T"
assert_contains "$out" "峰值/申请：25600.0%"

out="$(run_jres 106)"
assert_contains "$out" "状态：OUT_OF_MEMORY（内存不足）"
assert_contains "$out" "Slurm 观测峰值：727.1G"
assert_contains "$out" "提示：该作业因内存不足结束"
assert_contains "$out" "提示：观测峰值高于申请值"

out="$(run_jres 107)"
assert_contains "$out" "状态：NODE_FAIL（节点故障）"

out="$(run_jres 108)"
assert_contains "$out" "状态：WEIRD_STATE（未提供中文翻译）"

out="$(run_jres 109)"
assert_contains "$out" "申请：2G"

out="$(run_jres 110)"
assert_contains "$out" "申请：4G"

out="$(run_jres 111)"
assert_contains "$out" "Slurm 观测峰值：暂无可靠数据"
assert_contains "$out" "Slurm 记账数据可能尚未刷新"

out="$(run_jres 112)"
assert_contains "$out" "Slurm 观测峰值：700M"
assert_not_contains "$out" "900M"
assert_contains "$out" "非 extern step"

out="$(run_jres 113)"
assert_contains "$out" "多任务作业的 MaxRSS"

assert_fails env JRES_SACCT_LOG="$TMP_DIR/sacct.log" JRES_SSTAT_LOG="$TMP_DIR/sstat.log" JRES_SQUEUE_LOG="$TMP_DIR/squeue.log" PATH="$(make_env ambiguous):$PATH" bash "$JRES" 114
assert_contains "$(cat "$TMP_DIR/fail.err")" "多个父作业"

assert_fails env JRES_SACCT_LOG="$TMP_DIR/sacct.log" JRES_SSTAT_LOG="$TMP_DIR/sstat.log" JRES_SQUEUE_LOG="$TMP_DIR/squeue.log" PATH="$(make_env missing):$PATH" bash "$JRES" 115
assert_contains "$(cat "$TMP_DIR/fail.err")" "未找到作业"

assert_fails env JRES_SACCT_LOG="$TMP_DIR/sacct.log" JRES_SSTAT_LOG="$TMP_DIR/sstat.log" JRES_SQUEUE_LOG="$TMP_DIR/squeue.log" PATH="$(make_env noparent):$PATH" bash "$JRES" 116
assert_contains "$(cat "$TMP_DIR/fail.err")" "找不到精确父作业行"

out="$(run_jres 117)"
assert_contains "$out" "暂无可靠数据"
assert_contains "$out" "记账数据可能尚未刷新"

out="$(run_jres 118)"
assert_contains "$out" "时间字段"
assert_contains "$out" "平均等效使用：暂无可靠数据"

bindir="$(make_env sstat-fail)"
out="$(
    JRES_SACCT_LOG="$TMP_DIR/sacct.log" \
    JRES_SSTAT_LOG="$TMP_DIR/sstat.log" \
    JRES_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    JRES_SSTAT_FAIL=1 \
    PATH="$bindir:$PATH" \
    bash "$JRES" 101 2>"$TMP_DIR/sstat-fail.err"
)"
assert_contains "$out" "sstat 查询失败"
assert_contains "$(cat "$TMP_DIR/sstat-fail.err")" "sstat 查询失败"

bindir="$(make_env squeue-fail)"
out="$(
    JRES_SACCT_LOG="$TMP_DIR/sacct.log" \
    JRES_SSTAT_LOG="$TMP_DIR/sstat.log" \
    JRES_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    JRES_SQUEUE_FAIL=1 \
    PATH="$bindir:$PATH" \
    bash "$JRES" 102 2>"$TMP_DIR/squeue-fail.err"
)"
assert_contains "$out" "squeue 查询排队原因失败"

toolbin="$TMP_DIR/toolbin"
mkdir -p "$toolbin"
add_core_tools "$toolbin"
assert_fails env PATH="$toolbin" bash "$JRES" 100
assert_contains "$(cat "$TMP_DIR/fail.err")" "缺少必需命令：sacct"

bindir="$(make_env no-sstat)"
rm -f "$bindir/sstat"
add_core_tools "$bindir"
assert_fails env JRES_SACCT_LOG="$TMP_DIR/sacct.log" JRES_SSTAT_LOG="$TMP_DIR/sstat.log" JRES_SQUEUE_LOG="$TMP_DIR/squeue.log" PATH="$bindir" bash "$JRES" 101
assert_contains "$(cat "$TMP_DIR/fail.err")" "未找到 sstat"

bindir="$(make_env no-squeue)"
rm -f "$bindir/squeue"
add_core_tools "$bindir"
out="$(
    JRES_SACCT_LOG="$TMP_DIR/sacct.log" \
    JRES_SSTAT_LOG="$TMP_DIR/sstat.log" \
    JRES_SQUEUE_LOG="$TMP_DIR/squeue.log" \
    PATH="$bindir" \
    bash "$JRES" 102
)"
assert_contains "$out" "未找到 squeue"

bindir="$(make_env sacct-fail)"
assert_fails env JRES_SACCT_FAIL=1 JRES_SACCT_LOG="$TMP_DIR/sacct.log" JRES_SSTAT_LOG="$TMP_DIR/sstat.log" JRES_SQUEUE_LOG="$TMP_DIR/squeue.log" PATH="$bindir:$PATH" bash "$JRES" 100
assert_contains "$(cat "$TMP_DIR/fail.err")" "sacct 查询失败"

help_out="$(bash "$JRES" --help)"
assert_contains "$help_out" "jres JOBID"
assert_contains "$help_out" "jres JOBNAME"
assert_contains "$help_out" "jres --name JOBNAME"
assert_contains "$help_out" "完整、区分大小写的精确匹配"
assert_contains "$help_out" "运行中和排队中的作业不参与"
assert_fails bash "$JRES" 100 101
assert_fails bash "$JRES" --details 100
assert_fails bash "$JRES" --name

while IFS= read -r shell_file; do
    bash -n "$shell_file"
done < <(find "$ROOT_DIR" -type f -name '*.sh' ! -path "$ROOT_DIR/dist/*" | sort)
bash -n "$ROOT_DIR/bin/jres"

echo "jres_test.sh: PASS"
