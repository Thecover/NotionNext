# Changelog

## 0.2.0

- 新增 `mkcd` 目录创建并进入快捷函数。
- 新增 `nodeq` / `nq`，用于查看 `node01` 到 `node06` 的 Slurm 待运行作业。
- 新增 `jres` Slurm 作业资源报告，支持 Job ID、作业名和当前用户最近结束作业定位。
- 完善 `feedgpt` / `fgt` 数据提示词生成器。
- 完善 stable/dev 通道管理、开发版安装和自动测试覆盖。

## 0.1.0

- 建立 MoyuKit 项目结构和统一版本号。
- 新增 `tless`、`nf`、`rr` 三个 Bash 快捷函数。
- 新增 `moyu help`、`moyu version`、`moyu update` 管理命令。
- 新增用户级安装、卸载、本地隔离测试和发布包构建脚本。
- 新增稳定版 / 开发版持久化通道管理、公共 loader、开发版安装脚本和通道测试。
- 新增 `feedgpt` / `fgt` 数据提示词生成器及独立测试。
