#!/usr/bin/env bash

MOYUKIT_PROJECT_NAME="${MOYUKIT_PROJECT_NAME:-MoyuKit}"
MOYUKIT_DEFAULT_INSTALL_DIR="${MOYUKIT_DEFAULT_INSTALL_DIR:-${HOME}/.local/share/moyukit}"
MOYUKIT_SERVER_URL="${MOYUKIT_SERVER_URL:-https://ithecover.com/software/moyukit}"
