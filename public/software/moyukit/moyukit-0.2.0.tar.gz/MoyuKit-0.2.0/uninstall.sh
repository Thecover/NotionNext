#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
if [[ -r "$SCRIPT_DIR/lib/channel.sh" ]]; then
    # shellcheck source=/dev/null
    source "$SCRIPT_DIR/lib/channel.sh"
elif [[ -r "$(cd "$SCRIPT_DIR/.." 2>/dev/null && pwd -P)/lib/channel.sh" ]]; then
    # shellcheck source=/dev/null
    source "$(cd "$SCRIPT_DIR/.." && pwd -P)/lib/channel.sh"
fi

usage() {
    cat <<'EOF'
用法：
  bash uninstall.sh [--yes] [--dir DIR]
  bash uninstall.sh --help

选项：
  --yes      非交互确认，供测试脚本使用
  --dir DIR  指定要卸载的 MoyuKit 安装目录，默认使用当前脚本所在目录
EOF
}

fail() {
    echo "uninstall.sh: $*" >&2
    exit 1
}

require_channel_lib() {
    declare -F moyukit_load_paths >/dev/null 2>&1 ||
        fail "缺少通道管理库：lib/channel.sh"
}

detect_channel_for_dir() {
    local dir="$1"

    moyukit_load_paths
    if [[ "$dir" == "$MOYUKIT_STABLE_HOME_PATH" ]]; then
        printf 'stable\n'
    elif [[ "$dir" == "$MOYUKIT_DEV_HOME_PATH" ]]; then
        printf 'dev\n'
    else
        printf 'custom\n'
    fi
}

confirm_or_exit() {
    local assume_yes="$1"
    local prompt="$2"
    local answer

    if [[ "$assume_yes" == true ]]; then
        return 0
    fi

    printf '%s 输入 yes 继续：' "$prompt"
    IFS= read -r answer
    if [[ "$answer" != "yes" ]]; then
        echo "已取消。"
        exit 0
    fi
}

assert_safe_remove_dir() {
    local dir="$1"

    moyukit_assert_safe_user_dir "$dir" || fail "拒绝删除危险目录：$dir"
    [[ -d "$dir" ]] || fail "安装目录不存在：$dir"
    [[ -r "$dir/init.sh" && -r "$dir/VERSION" ]] || fail "目标目录不像 MoyuKit 安装目录：$dir"
}

main() {
    local assume_yes=false
    local install_dir="$SCRIPT_DIR"
    local target_channel active_channel other_channel other_home

    require_channel_lib

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --yes)
                assume_yes=true
                shift
                ;;
            --dir)
                [[ $# -ge 2 ]] || fail "--dir 需要参数"
                install_dir="$2"
                shift 2
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                fail "未知参数：$1"
                ;;
        esac
    done

    install_dir="$(moyukit_resolve_existing_path "$install_dir")" || fail "目录无效"
    assert_safe_remove_dir "$install_dir"
    target_channel="$(detect_channel_for_dir "$install_dir")"
    active_channel="$(moyukit_read_channel)"

    echo "即将删除 MoyuKit 安装目录：$install_dir"
    if [[ "$target_channel" != "custom" ]]; then
        echo "识别为通道：$target_channel"
    fi
    confirm_or_exit "$assume_yes" "确认卸载？"

    if [[ "$target_channel" == "$active_channel" ]]; then
        if [[ "$target_channel" == "stable" ]]; then
            other_channel="dev"
        else
            other_channel="stable"
        fi
        other_home="$(moyukit_channel_home "$other_channel")"
        if [[ -r "$other_home/init.sh" ]]; then
            confirm_or_exit "$assume_yes" "当前活动通道将被卸载，是否切换到 $other_channel？"
            moyukit_write_channel "$other_channel" || fail "切换到 $other_channel 失败"
            echo "持久化通道已切换为：$other_channel"
        else
            echo "当前活动通道将被卸载，且另一通道不可用。"
            rm -f "$(moyukit_channel_file)"
        fi
    fi

    rm -rf "$install_dir"
    moyukit_cleanup_shared_config_if_empty

    echo "MoyuKit 已卸载：$install_dir"
    echo "当前窗口若要完全刷新，可执行：exec bash -l"
}

main "$@"
