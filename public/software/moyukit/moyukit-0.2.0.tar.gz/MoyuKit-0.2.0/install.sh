#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
if [[ -r "$SCRIPT_DIR/config.sh" ]]; then
    # shellcheck source=/dev/null
    source "$SCRIPT_DIR/config.sh"
fi
if [[ -r "$SCRIPT_DIR/lib/channel.sh" ]]; then
    # shellcheck source=/dev/null
    source "$SCRIPT_DIR/lib/channel.sh"
fi

MOYUKIT_PROJECT_NAME="${MOYUKIT_PROJECT_NAME:-MoyuKit}"
MOYUKIT_DEFAULT_INSTALL_DIR="${MOYUKIT_DEFAULT_INSTALL_DIR:-${HOME}/.local/share/moyukit}"
MOYUKIT_SERVER_URL="${MOYUKIT_SERVER_URL:-}"
MOYUKIT_INSTALL_TMP_DIR=""

cleanup_install_tmp() {
    if [[ -n "${MOYUKIT_INSTALL_TMP_DIR:-}" ]]; then
        rm -rf "$MOYUKIT_INSTALL_TMP_DIR"
    fi
}

usage() {
    cat <<'EOF'
用法：
  bash install.sh [--dir DIR] [--local-source DIR]
  bash install.sh --help

选项：
  --dir DIR            指定稳定版安装目录，默认 $HOME/.local/share/moyukit
  --local-source DIR   从本地源码目录安装，主要用于隔离测试
  -h, --help           显示帮助
EOF
}

fail() {
    echo "install.sh: $*" >&2
    exit 1
}

require_channel_lib() {
    declare -F moyukit_expand_path >/dev/null 2>&1 ||
        fail "缺少通道管理库：lib/channel.sh"
}

check_dependencies() {
    local required=(bash awk column less tar curl sha256sum)
    local missing=()
    local dep

    for dep in "${required[@]}"; do
        if ! command -v "$dep" >/dev/null 2>&1; then
            missing+=("$dep")
        fi
    done

    if ((${#missing[@]} > 0)); then
        fail "缺少必需命令：${missing[*]}"
    fi

    if ! command -v Rscript >/dev/null 2>&1; then
        echo "install.sh: 提示：未找到 Rscript，rr 只有在当前环境存在 Rscript 时才能运行。" >&2
    fi
}

copy_local_source() {
    local source_dir="$1"
    local dest_dir="$2"

    [[ -d "$source_dir" ]] || fail "本地源码目录不存在：$source_dir"
    [[ -r "$source_dir/init.sh" && -r "$source_dir/VERSION" ]] || fail "本地源码目录结构不完整：$source_dir"

    mkdir -p "$dest_dir"
    tar \
        --exclude='./.git' \
        --exclude='./dist' \
        --exclude='./tmp' \
        --exclude='./tests/tmp' \
        --exclude='*.log' \
        --exclude='*.tmp' \
        --exclude='*.swp' \
        --exclude='*.swo' \
        --exclude='*~' \
        -C "$source_dir" -cf - . | tar -C "$dest_dir" -xf -
}

download_release() {
    local dest_dir="$1"
    local archive="$2"
    local sha_file="$3"
    local expected actual candidate

    [[ -n "$MOYUKIT_SERVER_URL" ]] || fail "未配置服务器地址，请检查 config.sh 或设置 MOYUKIT_SERVER_URL"

    if ! curl -fsSL "$MOYUKIT_SERVER_URL/latest.tar.gz" -o "$archive"; then
        fail "下载失败：$MOYUKIT_SERVER_URL/latest.tar.gz"
    fi

    if curl -fsSL "$MOYUKIT_SERVER_URL/latest.tar.gz.sha256" -o "$sha_file"; then
        if ! (cd "$(dirname "$archive")" && sha256sum -c "$(basename "$sha_file")" >/dev/null 2>&1); then
            expected="$(awk 'NR == 1 {print $1}' "$sha_file")"
            actual="$(sha256sum "$archive" | awk '{print $1}')"
            [[ -n "$expected" && "$expected" == "$actual" ]] || fail "SHA-256 校验失败"
        fi
    else
        echo "install.sh: 提示：未找到 SHA-256 文件，跳过校验。" >&2
    fi

    mkdir -p "$dest_dir/extract"
    tar -xzf "$archive" -C "$dest_dir/extract" || fail "解压失败"
    candidate="$(find "$dest_dir/extract" -mindepth 1 -maxdepth 2 -type f -name init.sh -print -quit)"
    [[ -n "$candidate" ]] || fail "发布包中未找到 init.sh"
    candidate="$(cd "$(dirname "$candidate")" && pwd -P)"
    tar -C "$candidate" -cf - . | tar -C "$dest_dir/source" -xf -
}

install_tree() {
    local source_dir="$1"
    local install_dir="$2"
    local tmp_dir="$3"
    local stage="$tmp_dir/stage"
    local backup=""
    local new_dir=""
    local parent

    mkdir -p "$stage"
    tar -C "$source_dir" -cf - . | tar -C "$stage" -xf -
    mkdir -p "$stage/bin"

    [[ -r "$stage/init.sh" && -r "$stage/VERSION" && -d "$stage/functions" && -r "$stage/lib/channel.sh" ]] ||
        fail "待安装内容结构不完整"
    [[ -f "$stage/bin/feedgpt" ]] && chmod 0755 "$stage/bin/feedgpt"
    [[ -f "$stage/bin/fgt" ]] && chmod 0755 "$stage/bin/fgt"
    [[ -f "$stage/bin/nodeq" ]] && chmod 0755 "$stage/bin/nodeq"
    [[ -e "$stage/bin/nq" ]] && chmod 0755 "$stage/bin/nq" 2>/dev/null || true
    [[ -f "$stage/bin/jres" ]] && chmod 0755 "$stage/bin/jres"

    parent="$(dirname "$install_dir")"
    mkdir -p "$parent"
    new_dir="$(mktemp -d "$parent/.moyukit-new.XXXXXX")" || fail "无法在目标目录旁创建临时目录"
    rmdir "$new_dir"

    if ! mv "$stage" "$new_dir"; then
        rm -rf "$new_dir"
        fail "无法准备新的安装目录：$new_dir"
    fi

    if [[ -e "$install_dir" ]]; then
        if [[ ! -d "$install_dir" ]]; then
            rm -rf "$new_dir"
            fail "目标路径已存在且不是目录：$install_dir"
        fi
        backup="$(mktemp -d "$parent/.moyukit-prev.XXXXXX")" || {
            rm -rf "$new_dir"
            fail "无法在目标目录旁创建备份目录"
        }
        rmdir "$backup"
        if ! mv "$install_dir" "$backup"; then
            rm -rf "$new_dir" "$backup"
            fail "无法暂存已有安装目录：$install_dir"
        fi
    fi

    if ! mv "$new_dir" "$install_dir"; then
        if [[ -n "$backup" && -d "$backup" ]]; then
            mv "$backup" "$install_dir"
        fi
        rm -rf "$new_dir"
        fail "写入安装目录失败：$install_dir"
    fi

    if [[ -n "$backup" ]]; then
        rm -rf "$backup"
    fi
}

main() {
    local install_dir="$MOYUKIT_DEFAULT_INSTALL_DIR"
    local local_source=""
    local tmp_dir source_dir archive sha_file current_channel

    require_channel_lib

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --dir)
                [[ $# -ge 2 ]] || fail "--dir 需要参数"
                install_dir="$2"
                shift 2
                ;;
            --local-source)
                [[ $# -ge 2 ]] || fail "--local-source 需要参数"
                local_source="$2"
                shift 2
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                fail "未知参数：$1"
                ;;
        esac
    done

    check_dependencies

    install_dir="$(moyukit_expand_path "$install_dir")" || fail "安装目录无效"
    moyukit_assert_safe_user_dir "$install_dir" || fail "拒绝使用危险安装目录：$install_dir"

    tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/moyukit-install.XXXXXX")"
    MOYUKIT_INSTALL_TMP_DIR="$tmp_dir"
    trap cleanup_install_tmp EXIT

    source_dir="$tmp_dir/source"
    mkdir -p "$source_dir"

    if [[ -n "$local_source" ]]; then
        local_source="$(moyukit_resolve_existing_path "$local_source")" || fail "本地源码目录无效"
        copy_local_source "$local_source" "$source_dir"
    else
        archive="$tmp_dir/latest.tar.gz"
        sha_file="$tmp_dir/latest.tar.gz.sha256"
        download_release "$tmp_dir" "$archive" "$sha_file"
    fi

    install_tree "$source_dir" "$install_dir" "$tmp_dir"
    moyukit_ensure_user_loader "$install_dir" "" "stable" ||
        fail "写入公共加载器失败"

    current_channel="$(moyukit_read_channel)"

    echo "MoyuKit 稳定版已安装到：$install_dir"
    echo "当前持久化通道：$current_channel"
    if [[ "$current_channel" == "stable" ]]; then
        echo "新开的 SSH/Bash 窗口会自动加载稳定版。"
        echo "当前窗口如需立即刷新，可执行：exec bash -l"
    else
        echo "当前仍保持开发通道；重新安装稳定版不会自动切回 stable。"
    fi
}

main "$@"
