#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd -P)"
if [[ -r "$ROOT_DIR/lib/channel.sh" ]]; then
    # shellcheck source=/dev/null
    source "$ROOT_DIR/lib/channel.sh"
fi

DEV_INSTALL_TMP_DIR=""

cleanup_dev_tmp() {
    if [[ -n "${DEV_INSTALL_TMP_DIR:-}" ]]; then
        rm -rf "$DEV_INSTALL_TMP_DIR"
    fi
}

usage() {
    cat <<'EOF'
用法：
  bash scripts/install_dev.sh [--source DIR] [--dir DIR] [--activate] [--force]
  bash scripts/install_dev.sh --help

选项：
  --source DIR   指定本地源码目录，默认当前项目根目录
  --dir DIR      指定开发版安装目录，默认 $HOME/.local/share/moyukit-dev
  --activate     安装成功后将持久化通道切换为 dev
  --force        允许替换非 MoyuKit 目录；仍会限制在指定目录本身
  -h, --help     显示帮助
EOF
}

fail() {
    echo "install_dev.sh: $*" >&2
    exit 1
}

require_channel_lib() {
    declare -F moyukit_expand_path >/dev/null 2>&1 ||
        fail "缺少通道管理库：lib/channel.sh"
}

copy_source() {
    local source_dir="$1"
    local dest_dir="$2"

    [[ -d "$source_dir" ]] || fail "源码目录不存在：$source_dir"
    [[ -r "$source_dir/init.sh" && -r "$source_dir/VERSION" && -r "$source_dir/lib/channel.sh" ]] ||
        fail "源码目录结构不完整：$source_dir"

    mkdir -p "$dest_dir"
    tar \
        --exclude='./.git' \
        --exclude='./dist' \
        --exclude='./tmp' \
        --exclude='./tests/tmp' \
        --exclude='*.log' \
        --exclude='*.tmp' \
        --exclude='*.swp' \
        --exclude='*.swo' \
        --exclude='*~' \
        -C "$source_dir" -cf - . | tar -C "$dest_dir" -xf -
}

install_dev_tree() {
    local source_dir="$1"
    local install_dir="$2"
    local tmp_dir="$3"
    local force="$4"
    local stage="$tmp_dir/stage"
    local new_dir backup parent

    mkdir -p "$stage"
    copy_source "$source_dir" "$stage"
    mkdir -p "$stage/bin"
    [[ -r "$stage/init.sh" && -r "$stage/VERSION" && -d "$stage/functions" && -r "$stage/lib/channel.sh" ]] ||
        fail "待安装内容结构不完整"
    [[ -f "$stage/bin/feedgpt" ]] && chmod 0755 "$stage/bin/feedgpt"
    [[ -f "$stage/bin/fgt" ]] && chmod 0755 "$stage/bin/fgt"
    [[ -f "$stage/bin/nodeq" ]] && chmod 0755 "$stage/bin/nodeq"
    [[ -e "$stage/bin/nq" ]] && chmod 0755 "$stage/bin/nq" 2>/dev/null || true
    [[ -f "$stage/bin/jres" ]] && chmod 0755 "$stage/bin/jres"

    parent="$(dirname "$install_dir")"
    mkdir -p "$parent"
    new_dir="$(mktemp -d "$parent/.moyukit-dev-new.XXXXXX")" || fail "无法在目标目录旁创建临时目录"
    rmdir "$new_dir"
    mv "$stage" "$new_dir"

    if [[ -e "$install_dir" ]]; then
        if [[ ! -d "$install_dir" ]]; then
            rm -rf "$new_dir"
            fail "目标路径已存在且不是目录：$install_dir"
        fi
        if [[ ! -r "$install_dir/init.sh" && "$force" != true ]]; then
            rm -rf "$new_dir"
            fail "目标目录不像 MoyuKit 开发版安装目录；如确认替换，请使用 --force"
        fi
        backup="$(mktemp -d "$parent/.moyukit-dev-prev.XXXXXX")" || {
            rm -rf "$new_dir"
            fail "无法创建回滚备份目录"
        }
        rmdir "$backup"
        if ! mv "$install_dir" "$backup"; then
            rm -rf "$new_dir" "$backup"
            fail "无法暂存已有开发版目录"
        fi
    else
        backup=""
    fi

    if ! mv "$new_dir" "$install_dir"; then
        if [[ -n "$backup" && -d "$backup" ]]; then
            mv "$backup" "$install_dir"
        fi
        rm -rf "$new_dir"
        fail "写入开发版目录失败，原安装已保留"
    fi

    if [[ -n "$backup" ]]; then
        rm -rf "$backup"
    fi
}

main() {
    local source_dir="$ROOT_DIR"
    local install_dir
    local activate=false
    local force=false
    local tmp_dir current_channel

    require_channel_lib
    install_dir="$(moyukit_default_dev_home)"

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --source)
                [[ $# -ge 2 ]] || fail "--source 需要参数"
                source_dir="$2"
                shift 2
                ;;
            --dir)
                [[ $# -ge 2 ]] || fail "--dir 需要参数"
                install_dir="$2"
                shift 2
                ;;
            --activate)
                activate=true
                shift
                ;;
            --force)
                force=true
                shift
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                fail "未知参数：$1"
                ;;
        esac
    done

    source_dir="$(moyukit_resolve_existing_path "$source_dir")" || fail "源码目录无效"
    install_dir="$(moyukit_expand_path "$install_dir")" || fail "开发版安装目录无效"
    moyukit_assert_safe_user_dir "$install_dir" || fail "拒绝使用危险安装目录：$install_dir"

    tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/moyukit-dev-install.XXXXXX")"
    DEV_INSTALL_TMP_DIR="$tmp_dir"
    trap cleanup_dev_tmp EXIT

    install_dev_tree "$source_dir" "$install_dir" "$tmp_dir" "$force"
    moyukit_ensure_user_loader "" "$install_dir" "stable" ||
        fail "写入公共加载器失败"

    if [[ "$activate" == true ]]; then
        moyukit_write_channel dev || fail "切换到 dev 通道失败"
    fi

    current_channel="$(moyukit_read_channel)"
    echo "MoyuKit 开发版已安装到：$install_dir"
    echo "当前持久化通道：$current_channel"
    if [[ "$activate" == true ]]; then
        echo "新开的 SSH/Bash 窗口会自动加载开发版。"
    else
        echo "未改变当前持久化通道；如需启用开发版，可执行：moyu channel dev"
    fi
    echo "当前窗口若要完全刷新，可执行：exec bash -l"
}

main "$@"
