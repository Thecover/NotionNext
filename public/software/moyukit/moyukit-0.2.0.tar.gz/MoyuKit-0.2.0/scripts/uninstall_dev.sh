#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd -P)"
if [[ -r "$ROOT_DIR/lib/channel.sh" ]]; then
    # shellcheck source=/dev/null
    source "$ROOT_DIR/lib/channel.sh"
fi

usage() {
    cat <<'EOF'
用法：
  bash scripts/uninstall_dev.sh [--yes] [--dir DIR]
  bash scripts/uninstall_dev.sh --help

选项：
  --yes      非交互确认，供测试脚本使用
  --dir DIR  指定开发版安装目录，默认读取 paths.conf 或 $HOME/.local/share/moyukit-dev
EOF
}

fail() {
    echo "uninstall_dev.sh: $*" >&2
    exit 1
}

main() {
    local assume_yes=false
    local dir=""
    local args=()

    declare -F moyukit_load_paths >/dev/null 2>&1 ||
        fail "缺少通道管理库：lib/channel.sh"

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --yes)
                assume_yes=true
                shift
                ;;
            --dir)
                [[ $# -ge 2 ]] || fail "--dir 需要参数"
                dir="$2"
                shift 2
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                fail "未知参数：$1"
                ;;
        esac
    done

    if [[ -z "$dir" ]]; then
        moyukit_load_paths
        dir="$MOYUKIT_DEV_HOME_PATH"
    fi

    if [[ "$assume_yes" == true ]]; then
        args+=(--yes)
    fi
    args+=(--dir "$dir")

    bash "$ROOT_DIR/uninstall.sh" "${args[@]}"
}

main "$@"
