# MoyuKit 摸鱼工具箱

MoyuKit 是一套面向课题组 Linux 服务器用户的快捷工具集合，用于简化常见操作、减少重复命令输入。

少敲几行命令，多留一点时间。

## 用户级全局安装

MoyuKit 采用用户级全局安装：文件默认放在当前用户自己的目录中，不写入 `/usr`、`/etc`、`/opt` 等系统目录，也不需要 `sudo`。安装脚本只会修改当前用户的 `~/.bashrc`，并且只维护带固定标记的 MoyuKit 加载区块。

稳定版默认安装目录：

```bash
$HOME/.local/share/moyukit
```

开发版默认安装目录：

```bash
$HOME/.local/share/moyukit-dev
```

自定义安装目录：

```bash
bash install.sh --dir "$HOME/tools/moyukit"
```

MoyuKit 使用持久公共加载器：

```bash
$HOME/.config/moyukit/loader.sh
```

当前通道保存在：

```bash
$HOME/.config/moyukit/channel
```

`.bashrc` 只加载公共 loader，不直接指向稳定版或开发版目录。安装或切换通道后，新建 Bash 终端会自动加载当前持久化通道；当前窗口若要完全刷新，可执行：

```bash
exec bash -l
```

## 安装

部署服务器地址后，普通用户可以一行安装：

```bash
tmp="$(mktemp -d)" && curl -fsSL https://ithecover.com/software/moyukit/install.sh -o "$tmp/install.sh" && MOYUKIT_SERVER_URL=https://ithecover.com/software/moyukit bash "$tmp/install.sh"
```

开发目录中的本地测试安装：

```bash
bash install.sh --local-source /data6A/wuying/projects/MoyuKit
```

正式部署服务器地址后，可以从发布服务器安装。当前占位地址为：

```text
https://ithecover.com/software/moyukit
```

管理员部署时需要把项目中的服务器占位符统一替换为真实地址。

## Conda 环境行为

MoyuKit 的命令由 Bash 加载。切换 Conda 环境后，`tless`、`nf`、`rr`、`moyu` 这些 Bash 函数仍然存在。实际调用哪个外部程序取决于当前环境的 `PATH`，例如 `rr` 使用的 `Rscript` 就由当前 Conda 环境或系统路径决定。

## tless

`tless` 是 table less 的缩写，用于对齐并分页查看表格。

```bash
tless file.tsv
tless file.vcf
tless file.vcf.gz
command | tless
```

参数：

```text
-H, --header    显示以 ## 开头的元信息行
-n N            显示前 N 行有效数据，N 可以为 0，0 表示全部
-a, -A, --all   显示全部有效数据
```

默认行为：

```text
隐藏以 ## 开头的元信息行
保留 #CHROM 等不以 ## 开头的列名行
默认显示前 100 行非 ## 行
支持普通文件、.gz 文件和标准输入
使用 column -t 对齐
使用 less -S 分页，支持左右方向键查看宽表格
```

`column -t` 需要读完传给它的内容后才能计算列宽，因此对超大文件使用 `-a` 或 `--all` 可能较慢。`tless` 适合 TSV、VCF 和空白字符分隔表格，不是专门的 CSV 查看器。

## nf

`nf` 是 new file 的缩写，用于直接在终端中创建或追加文本文件。

```bash
nf filename
nf -a filename
```

默认模式会覆盖创建文件，并且会在开始输入前清空同名文件。输入单独一行 `EOF` 或 `eof` 时结束。

追加模式：

```bash
nf -a notes.txt
```

## rr

`rr` 是 Run R 的缩写。

```bash
rr
```

等价于：

```bash
Rscript 1.r
```

指定脚本：

```bash
rr analysis.R
```

等价于：

```bash
Rscript analysis.R
```

`1.r` 主要用于一次性临时脚本。如果当前环境没有 `Rscript`，`rr` 会给出明确提示并退出。

## mkcd

`mkcd` 用于递归创建目录并立即进入该目录。它必须作为 Bash 函数加载，才能改变当前 Shell 的工作目录。

```bash
mkcd DIR
```

等价于：

```bash
mkdir -p -- DIR && cd -- DIR
```

示例：

```bash
mkcd analysis/result
mkcd "/data/project/new result"
mkcd -- -test
```

`mkcd` 只接受一个目标目录；创建失败时不会执行 `cd`，也不会自动执行 `ls` 或创建模板文件。

## feedgpt / fgt

`feedgpt` 是数据提示词生成器，用于把服务器上的表格文件路径、表头、前几行格式、列名和指定元数据列的取值范围整理成 Markdown 文本，方便复制给 ChatGPT、Codex 等模型继续讨论分析或绘图代码。

简写命令：

```bash
fgt
```

用法：

```bash
feedgpt [MODE] FILE [OPTIONS]
fgt [MODE] FILE [OPTIONS]
```

模式：

```text
auto                 自动判断，默认
matrix, ma           矩阵模式
metadata, me         元数据模式
```

常用示例：

```bash
fgt file.txt
fgt ma count.txt -r 5 -c 20
fgt me sample_info.txt -u Stage,Tissue
fgt metadata sample_info.txt --unique Stage --unique Tissue
fgt me info.txt -u PigID -l 50
fgt me info.txt -u PigID -A
fgt -- -strange-file.txt
```

参数：

```text
-h, --help             显示帮助
-r, --rows N           展示的数据行数，不包括表头，默认 3
-c, --columns N        最大展示列数，包括第一列，默认 12
-u, --unique COLS      输出指定列的有序非重复值，支持列名或从 1 开始的列号
-l, --max-values N     每个唯一值列表最多展示的数量，默认 30
-A, --all-values       展示指定列的全部唯一值
-s, --separator TYPE   分隔符：auto、tab、whitespace，默认 auto
```

支持普通文本文件和 `.gz` 文件；支持 Tab 分隔表和连续空白字符分隔表。复杂 CSV 引号语义、Excel、JSON、YAML、自动上传、GPT API 和剪贴板操作暂不支持。

自动模式只做保守推断：列数较多、第一列外多数预览字段可解析为数字时倾向 `matrix`，否则倾向 `metadata`。它不会判断数据是否适合某种统计分析，也不会自动推断 count、TPM 或 DESeq2 输入等生物学含义。

默认预览只读取少量行；只有使用 `-u/--unique` 时才扫描整张表。唯一值保持文件中首次出现的顺序，`NA`、`N/A`、`NULL`、`.` 会按原值保留，真正的空字段不会加入唯一值列表。

把输出复制给外部模型前，请先检查是否包含样本名、绝对路径或其他敏感信息。

## nodeq / nq

`nodeq` 用于简洁查看 Slurm 中 `node01` 到 `node06` 的待运行作业；`nq` 是同一命令的简写。

```bash
nodeq
nq
nq node03
nq -u wuying
nq node03 -u wuying
```

默认只查询 `PD` 状态，不显示运行中作业。输出按固定顺序显示 `node01` 到 `node06`，最后显示未明确指定节点的作业。

每行中的 `CPUS` 和 `MEM_REQ` 是作业申请的 CPU 数和申请内存，不是实际使用量。`MEM_REQ` 默认使用 Slurm 报告的申请内存；在当前服务器上，使用 `--noconvert` 后常见内存会以 `M` 为单位返回，MoyuKit 会把能整除的整数 M 转为更易读的 G 或 T，例如 `153600M` 显示为 `150G`，`32000M` 和 `150000M` 保持原样。`--mem-per-cpu` 尚无真实待运行样例验证，遇到特殊或未验证格式会优先原样保留。

`nodeq` 使用提交时明确请求的节点归类，不把排除节点或调度器预测节点当作请求节点。未指定 `-w` 的作业会列在 `[未指定节点]`。如果一个作业明确请求多个节点，它可能在多个节点分组中重复显示。

`WAIT` 来自 Slurm 的 `PendingTime`，只表示已经等待的时间，不代表排队名次或预计开始时间。`REASON` 保留 Slurm 原始原因，例如 `Priority`、`Resources`、`ReqNodeNotAvail`；一个作业可能同时受到多个条件影响。

## jres

`jres` 是 job resources 的缩写，用于查看一个 Slurm 作业的资源申请与 Slurm 记账/采样到的资源使用情况。

```bash
jres 24455
jres test
jres
jres --name 24455
jres -h
```

三种入口含义：

```text
jres JOBID            查看明确指定的 Slurm Job ID，优先级最高
jres JOBNAME          按作业名精确匹配，选择当前用户最近结束的同名作业
jres                  选择当前用户最近结束的任意作业
jres --name JOBNAME   强制作业名匹配，适合纯数字作业名
```

按作业名和无参数模式只查询当前登录用户最近 90 天内已经结束的作业；同名作业按 `End` 时间选择最近结束的一个，结束时间相同再按 `JobIDRaw` 选择较大的记录。作业名匹配是完整、区分大小写的字面匹配：`test` 不会匹配 `test1`、`mytest` 或 `Test`。失败、取消、超时、OOM、节点故障等已结束作业也会参与选择；运行中和排队中的作业不会参与名称自动定位，可使用明确 Job ID 直接查询。

默认输出会根据作业状态展示：

```text
作业概览：JOBID、名称、状态、退出码、运行时间、节点
资源申请：CPU、内存、节点数、任务数
CPU 使用：已结束作业的 TotalCPU、平均使用核心数和相对申请 CPU 的使用比例
内存使用：Slurm 观测到的峰值内存，以及相对申请内存的比例
提示信息：记账延迟、运行中作业、OOM、多任务作业等需要注意的情况
```

`jres` 对已结束作业主要读取 `sacct`；对运行中作业会额外读取一次 `sstat`；对待运行作业会尝试用 `squeue` 补充 Pending 原因和请求节点。它不会提交、取消或修改任何作业。

CPU 使用量来自 Slurm 记账字段，不是实时 `top` 输出。已结束作业的平均使用核心数按 `TotalCPU / Elapsed` 计算，CPU 使用比例按 `TotalCPU / CPUTimeRAW` 计算。运行中作业的 CPU 使用比例暂不做可靠计算。

内存申请优先来自 `ReqTRES` 中的 `mem=`，其次尝试 `AllocTRES` 和 `ReqMem`。内存峰值优先使用 `.batch` 步骤的 `MaxRSS` 或 `TRESUsageInMax`；没有 `.batch` 数据时，会使用非 `.extern` 步骤中的最大可用值作为保守回退。该值是 Slurm 观测峰值，受当前服务器 30 秒左右的作业采样间隔影响，可能低估瞬时峰值。

如果作业刚结束或记账尚未刷新，`sacct` 可能暂时没有记录；此时可以稍等片刻再运行 `jres JOBID`。当同一个查询返回多个父作业行时，`jres` 会拒绝自动聚合，避免把数组作业或相似 Job ID 的数据混在一起。

## 管理命令

```bash
moyu help
moyu version
moyu update
moyu channel
moyu channel status
moyu channel stable
moyu channel dev
```

`moyu help` 也会列出常用工具：`tless`、`nf`、`rr`、`mkcd`、`feedgpt / fgt`、`nodeq / nq`、`jres [JOBID|JOBNAME]`。

`moyu version` 会读取当前安装目录中的 `VERSION`，显示类似：

```text
MoyuKit 0.2.0 (stable)
MoyuKit 0.2.0-dev (dev)
```

`moyu update` 会从配置的服务器地址下载最新版压缩包，在临时目录中完成下载、解压和校验，确认成功后再替换当前用户的安装目录。下载失败、解压失败或 SHA-256 校验失败时，不会破坏现有安装。MoyuKit 不会在打开 Shell 时自动联网检查更新。

`moyu channel status` 会显示当前持久化通道、当前 Shell 实际加载通道、稳定版和开发版路径及安装状态。`moyu channel stable` 和 `moyu channel dev` 会切换未来新 SSH/Bash 窗口使用的通道，但不会自动执行 `exec bash` 打断当前工作。

`moyu update` 只更新稳定版。当前 Shell 处于开发通道时会拒绝执行线上稳定版覆盖，并提示在源码目录运行 `scripts/install_dev.sh` 更新开发版。

## 开发版安装

维护者可以从本地源码安装开发版：

```bash
bash scripts/install_dev.sh
bash scripts/install_dev.sh --source /data6A/wuying/projects/MoyuKit
bash scripts/install_dev.sh --dir "$HOME/other/moyukit-dev"
bash scripts/install_dev.sh --activate
```

默认只安装或覆盖开发版，不改变当前持久通道。加上 `--activate` 后，安装成功会把持久化通道切换为 `dev`。开发版安装不访问线上网址，不修改稳定版目录，也不改 `MOYUKIT_SERVER_URL`。

## 卸载

在已安装目录中运行：

```bash
bash uninstall.sh
```

卸载脚本会显示即将删除的安装目录，并要求确认。它会删除当前安装目录和 `~/.bashrc` 中的 MoyuKit 固定标记区块，不会删除 `.bashrc` 备份，也不会修改其他配置。

稳定版和开发版可以分别卸载。只有两套都不存在时，卸载才会清理公共 loader、通道状态和 `.bashrc` 中的 MoyuKit 区块。

测试脚本使用非交互参数：

```bash
bash uninstall.sh --yes
```

## 开发目录与安装目录

`/data6A/wuying/projects/MoyuKit` 是开发源码目录，不等同于正式安装目录。稳定版安装目录默认是 `$HOME/.local/share/moyukit`，开发版安装目录默认是 `$HOME/.local/share/moyukit-dev`。测试必须使用临时 `HOME`，不要修改真实 `~/.bashrc`。

## Slurm 批处理

Slurm 批处理脚本不一定读取交互式 Bash 的 `~/.bashrc`。正式批处理脚本中建议直接使用原始命令，或显式加载 MoyuKit：

```bash
source "$HOME/.local/share/moyukit/init.sh"
```

如果使用了自定义安装目录，请把路径替换为实际安装目录。

## 已知限制

`nf` 使用简单的逐行输入机制，不处理复杂终端编辑行为。部分终端中退格键可能显示为 `^H`，当前版本不处理该问题。

`tless` 依赖 `column`、`less`、`awk` 等常见命令；查看 `.gz` 文件时需要 `zcat` 或 `gzip`。缺少可选命令时，MoyuKit 只会提示，不会调用包管理器。

当前服务器地址仍是占位符 `https://ithecover.com/software/moyukit`，管理员部署时需要统一替换。
