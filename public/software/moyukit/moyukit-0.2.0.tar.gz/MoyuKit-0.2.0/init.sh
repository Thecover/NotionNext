#!/usr/bin/env bash

_moyukit_init() {
    local init_file init_dir bin_dir old_nullglob func_file
    local config_dir paths_file line key value stable_home dev_home channel
    local path_part new_path

    init_file="${1:?}"
    init_dir="$(cd "$(dirname "$init_file")" && pwd -P)" || return 1

    config_dir="${HOME}/.config/moyukit"
    paths_file="$config_dir/paths.conf"
    stable_home="${HOME}/.local/share/moyukit"
    dev_home="${HOME}/.local/share/moyukit-dev"

    if [[ -r "$paths_file" ]]; then
        while IFS= read -r line || [[ -n "$line" ]]; do
            case "$line" in
                ""|\#*) continue ;;
                *=*)
                    key="${line%%=*}"
                    value="${line#*=}"
                    ;;
                *) continue ;;
            esac
            [[ "$value" == /* && "$value" != *$'\n'* ]] || continue
            case "$key" in
                stable_home) stable_home="$value" ;;
                dev_home) dev_home="$value" ;;
            esac
        done < "$paths_file"
    fi

    channel="${MOYUKIT_CHANNEL:-}"
    if [[ "$channel" != "stable" && "$channel" != "dev" ]]; then
        if [[ "$init_dir" == "$dev_home" ]]; then
            channel="dev"
        else
            channel="stable"
        fi
    fi

    MOYUKIT_HOME="$init_dir"
    MOYUKIT_CHANNEL="$channel"
    export MOYUKIT_HOME MOYUKIT_CHANNEL

    if [[ -r "$MOYUKIT_HOME/config.sh" ]]; then
        # shellcheck source=/dev/null
        source "$MOYUKIT_HOME/config.sh"
    fi

    bin_dir="$MOYUKIT_HOME/bin"
    new_path=""
    IFS=':' read -r -a _moyukit_path_parts <<< "${PATH:-}"
    for path_part in "${_moyukit_path_parts[@]}"; do
        case "$path_part" in
            "$stable_home/bin"|"$dev_home/bin"|"") continue ;;
        esac
        if [[ -z "$new_path" ]]; then
            new_path="$path_part"
        else
            new_path="$new_path:$path_part"
        fi
    done
    unset _moyukit_path_parts

    PATH="$bin_dir${new_path:+:$new_path}"
    export PATH

    old_nullglob="$(shopt -p nullglob || true)"
    shopt -s nullglob
    for func_file in "$MOYUKIT_HOME"/functions/*.sh; do
        # shellcheck source=/dev/null
        source "$func_file"
    done
    eval "$old_nullglob"
}

_moyukit_init "${BASH_SOURCE[0]}"
unset -f _moyukit_init
