#!/usr/bin/env bash

if [[ -r "${MOYUKIT_HOME:-}/lib/channel.sh" ]]; then
    # shellcheck source=/dev/null
    source "${MOYUKIT_HOME}/lib/channel.sh"
fi

moyu() {
    local cmd="${1:-help}"

    case "$cmd" in
        help|-h|--help)
            cat <<'EOF'
MoyuKit 管理命令

用法：
  moyu help
  moyu version
  moyu update
  moyu channel
  moyu channel status
  moyu channel stable
  moyu channel dev

常用工具：
  tless
  nf
  rr
  mkcd
  feedgpt / fgt
  nodeq / nq
  jres [JOBID|JOBNAME]    查看指定或最近结束作业的资源使用
EOF
            ;;
        version)
            _moyu_version
            ;;
        update)
            _moyu_update
            ;;
        channel)
            shift
            _moyu_channel "$@"
            ;;
        *)
            echo "moyu: 未知命令：$cmd" >&2
            echo "请运行：moyu help" >&2
            return 1
            ;;
    esac
}

_moyu_version() {
    local version channel suffix

    channel="${MOYUKIT_CHANNEL:-stable}"
    if [[ -r "${MOYUKIT_HOME:-}/VERSION" ]]; then
        version="$(tr -d '[:space:]' < "${MOYUKIT_HOME}/VERSION")"
    else
        echo "moyu version: 无法读取 VERSION 文件" >&2
        return 1
    fi

    suffix=""
    if [[ "$channel" == "dev" ]]; then
        suffix="-dev"
    fi

    printf 'MoyuKit %s%s (%s)\n' "$version" "$suffix" "$channel"
}

_moyu_channel() {
    local subcmd="${1:-status}"
    local persistent actual stable_home dev_home stable_status dev_status version

    if ! declare -F moyukit_load_paths >/dev/null 2>&1; then
        echo "moyu channel: 缺少通道管理库 lib/channel.sh" >&2
        return 1
    fi

    case "$subcmd" in
        ""|status)
            moyukit_load_paths
            persistent="$(moyukit_read_channel)"
            actual="${MOYUKIT_CHANNEL:-unknown}"
            stable_home="$MOYUKIT_STABLE_HOME_PATH"
            dev_home="$MOYUKIT_DEV_HOME_PATH"
            stable_status="missing"
            dev_status="missing"
            [[ -r "$stable_home/init.sh" ]] && stable_status="installed"
            [[ -r "$dev_home/init.sh" ]] && dev_status="installed"
            version="unknown"
            if [[ -r "${MOYUKIT_HOME:-}/VERSION" ]]; then
                version="$(tr -d '[:space:]' < "${MOYUKIT_HOME}/VERSION")"
                [[ "$actual" == "dev" ]] && version="${version}-dev"
            fi

            cat <<EOF
MoyuKit 通道状态
  持久化通道：$persistent
  当前 Shell 加载通道：$actual
  稳定版路径：$stable_home ($stable_status)
  开发版路径：$dev_home ($dev_status)
  当前版本：$version
EOF
            ;;
        stable|dev)
            _moyu_channel_switch "$subcmd"
            ;;
        *)
            echo "moyu channel: 未知通道命令：$subcmd" >&2
            echo "可用命令：moyu channel status | stable | dev" >&2
            return 1
            ;;
    esac
}

_moyu_channel_switch() {
    local target="$1"
    local target_home target_init

    target_home="$(moyukit_channel_home "$target")" || {
        echo "moyu channel: 无法读取 $target 通道路径" >&2
        return 1
    }
    target_init="$target_home/init.sh"

    if [[ ! -r "$target_init" ]]; then
        echo "moyu channel: 无法切换到 $target，未找到可读文件：$target_init" >&2
        echo "请先安装该通道，然后重试。" >&2
        return 1
    fi

    moyukit_write_channel "$target" || {
        echo "moyu channel: 写入通道状态失败" >&2
        return 1
    }

    echo "MoyuKit 持久化通道已切换为：$target"
    echo "新开的 SSH/Bash 窗口会自动使用 $target 通道。"
    echo "当前窗口若要完全刷新，可执行：exec bash -l"
    echo "注意：简单 source 新通道不能保证清理旧通道独有函数。"
}

_moyu_update() {
    local install_dir server_url tmp_dir archive sha_file extract_dir candidate parent backup
    local missing=() dep expected actual

    if [[ "${MOYUKIT_CHANNEL:-stable}" == "dev" ]]; then
        cat >&2 <<'EOF'
moyu update: 当前正在使用开发通道。
请在源码目录运行 scripts/install_dev.sh 覆盖开发版；
如需更新稳定版，请先切换到 stable。
EOF
        return 1
    fi

    install_dir="${MOYUKIT_HOME:-}"
    server_url="${MOYUKIT_SERVER_URL:-}"

    if [[ -z "$install_dir" || ! -d "$install_dir" ]]; then
        echo "moyu update: 无法确定当前安装目录" >&2
        return 1
    fi

    if [[ -z "$server_url" ]]; then
        echo "moyu update: 未配置服务器地址，请检查 config.sh 或设置 MOYUKIT_SERVER_URL" >&2
        return 1
    fi

    case "$install_dir" in
        /|/usr|/usr/*|/etc|/etc/*|/opt|/opt/*|/bin|/bin/*|/sbin|/sbin/*)
            echo "moyu update: 拒绝更新系统目录：$install_dir" >&2
            return 1
            ;;
    esac

    for dep in curl tar sha256sum awk; do
        if ! command -v "$dep" >/dev/null 2>&1; then
            missing+=("$dep")
        fi
    done
    if ((${#missing[@]} > 0)); then
        echo "moyu update: 缺少必需命令：${missing[*]}" >&2
        return 1
    fi

    tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/moyukit-update.XXXXXX")" || return 1
    archive="$tmp_dir/latest.tar.gz"
    sha_file="$tmp_dir/latest.tar.gz.sha256"
    extract_dir="$tmp_dir/extract"
    mkdir -p "$extract_dir"

    if ! curl -fsSL "$server_url/latest.tar.gz" -o "$archive"; then
        echo "moyu update: 下载失败：$server_url/latest.tar.gz" >&2
        rm -rf "$tmp_dir"
        return 1
    fi

    if curl -fsSL "$server_url/latest.tar.gz.sha256" -o "$sha_file"; then
        if ! (cd "$tmp_dir" && sha256sum -c "$(basename "$sha_file")" >/dev/null 2>&1); then
            expected="$(awk 'NR == 1 {print $1}' "$sha_file")"
            actual="$(sha256sum "$archive" | awk '{print $1}')"
            if [[ -z "$expected" || "$expected" != "$actual" ]]; then
                echo "moyu update: SHA-256 校验失败" >&2
                rm -rf "$tmp_dir"
                return 1
            fi
        fi
    else
        echo "moyu update: 未找到 SHA-256 文件，跳过校验" >&2
    fi

    if ! tar -xzf "$archive" -C "$extract_dir"; then
        echo "moyu update: 解压失败，现有安装未修改" >&2
        rm -rf "$tmp_dir"
        return 1
    fi

    candidate="$(find "$extract_dir" -mindepth 1 -maxdepth 2 -type f -name init.sh -print -quit)"
    if [[ -z "$candidate" ]]; then
        echo "moyu update: 发布包中未找到 init.sh" >&2
        rm -rf "$tmp_dir"
        return 1
    fi
    candidate="$(cd "$(dirname "$candidate")" && pwd -P)"

    if [[ ! -r "$candidate/VERSION" || ! -d "$candidate/functions" ]]; then
        echo "moyu update: 发布包结构不完整" >&2
        rm -rf "$tmp_dir"
        return 1
    fi
    mkdir -p "$candidate/bin"

    parent="$(dirname "$install_dir")"
    backup="$(mktemp -d "$parent/.moyukit-prev.XXXXXX")" || {
        echo "moyu update: 无法在安装目录旁创建备份目录" >&2
        rm -rf "$tmp_dir"
        return 1
    }
    rmdir "$backup"

    if ! mv "$install_dir" "$backup"; then
        echo "moyu update: 无法暂存现有安装目录" >&2
        rm -rf "$tmp_dir" "$backup"
        return 1
    fi

    if ! mv "$candidate" "$install_dir"; then
        echo "moyu update: 替换安装目录失败，正在恢复旧版本" >&2
        mkdir -p "$parent"
        mv "$backup" "$install_dir"
        rm -rf "$tmp_dir"
        return 1
    fi

    rm -rf "$backup" "$tmp_dir"

    if [[ -r "$install_dir/lib/channel.sh" ]]; then
        # shellcheck source=/dev/null
        source "$install_dir/lib/channel.sh"
        moyukit_ensure_user_loader "$install_dir" "" "stable"
    fi

    if [[ -r "$install_dir/init.sh" ]]; then
        MOYUKIT_CHANNEL="stable"
        # shellcheck source=/dev/null
        source "$install_dir/init.sh"
    fi

    echo "MoyuKit 稳定版已更新：$install_dir"
}
