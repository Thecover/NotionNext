#!/usr/bin/env bash

nf() {
    local append=false
    local filename=""
    local line

    case "${1:-}" in
        -a)
            append=true
            filename="${2:-}"
            if [[ $# -gt 2 ]]; then
                echo "nf: 参数过多" >&2
                return 1
            fi
            ;;
        -h|--help)
            cat <<'EOF'
用法：
  nf <文件名>
  nf -a <文件名>
输入单独一行 EOF 或 eof 时结束。
EOF
            return 0
            ;;
        -*)
            echo "nf: 未知参数：$1" >&2
            return 1
            ;;
        *)
            filename="${1:-}"
            if [[ $# -gt 1 ]]; then
                echo "nf: 参数过多" >&2
                return 1
            fi
            ;;
    esac

    if [[ -z "$filename" ]]; then
        echo "请提供文件名！" >&2
        echo "用法 1：nf <文件名>" >&2
        echo "用法 2：nf -a <文件名>" >&2
        return 1
    fi

    if [[ "$append" == true ]]; then
        : >> "$filename" || {
            echo "nf: 无法写入文件：$filename" >&2
            return 1
        }
    else
        : > "$filename" || {
            echo "nf: 无法创建文件：$filename" >&2
            return 1
        }
    fi

    while IFS= read -r line; do
        if [[ "$line" == "eof" || "$line" == "EOF" ]]; then
            break
        fi
        printf '%s\n' "$line" >> "$filename" || {
            echo "nf: 写入失败：$filename" >&2
            return 1
        }
    done
}
