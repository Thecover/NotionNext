#!/usr/bin/env bash

mkcd() {
    local dir

    case "$#" in
        0)
            echo "用法：mkcd DIR" >&2
            return 1
            ;;
        1)
            dir="$1"
            ;;
        2)
            if [[ "$1" == "--" ]]; then
                dir="$2"
            else
                echo "mkcd: 参数过多" >&2
                echo "用法：mkcd DIR" >&2
                return 1
            fi
            ;;
        *)
            echo "mkcd: 参数过多" >&2
            echo "用法：mkcd DIR" >&2
            return 1
            ;;
    esac

    if [[ -z "$dir" ]]; then
        echo "mkcd: 目录不能为空" >&2
        return 1
    fi

    mkdir -p -- "$dir" || {
        echo "mkcd: 无法创建目录：$dir" >&2
        return 1
    }

    cd -- "$dir" || {
        echo "mkcd: 无法进入目录：$dir" >&2
        return 1
    }
}
