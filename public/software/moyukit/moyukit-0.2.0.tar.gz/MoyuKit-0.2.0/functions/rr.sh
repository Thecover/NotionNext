#!/usr/bin/env bash

rr() {
    if ! command -v Rscript >/dev/null 2>&1; then
        echo "rr: 当前环境没有 Rscript，无法运行 R 脚本" >&2
        return 127
    fi

    Rscript "${1:-1.r}"
}
