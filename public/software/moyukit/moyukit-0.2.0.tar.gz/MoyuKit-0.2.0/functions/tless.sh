#!/usr/bin/env bash

tless() {
    local show_header=false
    local file=""
    local limit=100
    local awk_cmd

    while [[ "$#" -gt 0 ]]; do
        case "$1" in
            -H|--header)
                show_header=true
                shift
                ;;
            -n)
                if [[ $# -lt 2 ]]; then
                    echo "tless: -n 需要提供行数" >&2
                    return 1
                fi
                if [[ ! "$2" =~ ^[0-9]+$ ]]; then
                    echo "tless: -n 的参数必须是正整数或 0" >&2
                    return 1
                fi
                limit="$2"
                shift 2
                ;;
            -a|-A|--all)
                limit=0
                shift
                ;;
            -h|--help)
                cat <<'EOF'
用法：
  tless [-H|--header] [-n N|-a|--all] file
  command | tless [-H|--header] [-n N|-a|--all]
EOF
                return 0
                ;;
            -*)
                echo "tless: 未知参数：$1" >&2
                return 1
                ;;
            *)
                if [[ -n "$file" ]]; then
                    echo "tless: 只能提供一个文件" >&2
                    return 1
                fi
                file="$1"
                shift
                ;;
        esac
    done

    if [[ -z "$file" && -t 0 ]]; then
        echo "tless: 请提供文件名或通过管道传入数据" >&2
        return 1
    fi

    for dep in awk column less; do
        if ! command -v "$dep" >/dev/null 2>&1; then
            echo "tless: 缺少必需命令：$dep" >&2
            return 1
        fi
    done

    if [[ -n "$file" ]]; then
        if [[ ! -e "$file" ]]; then
            echo "tless: 文件不存在：$file" >&2
            return 1
        fi
        if [[ ! -r "$file" ]]; then
            echo "tless: 文件不可读：$file" >&2
            return 1
        fi
    fi

    awk_cmd='BEGIN { c = "column -t"; d = 0 }
/^##/ { if (s == "true") print; next }
{ print | c; d++; if (l > 0 && d >= l) exit }
END { close(c) }'

    if [[ -n "$file" && "$file" == *.gz ]]; then
        if command -v zcat >/dev/null 2>&1; then
            zcat "$file" | awk -v s="$show_header" -v l="$limit" "$awk_cmd" | less -S
        elif command -v gzip >/dev/null 2>&1; then
            gzip -cd "$file" | awk -v s="$show_header" -v l="$limit" "$awk_cmd" | less -S
        else
            echo "tless: 查看 .gz 文件需要 zcat 或 gzip" >&2
            return 1
        fi
    elif [[ -n "$file" ]]; then
        awk -v s="$show_header" -v l="$limit" "$awk_cmd" "$file" | less -S
    else
        awk -v s="$show_header" -v l="$limit" "$awk_cmd" | less -S
    fi
}
