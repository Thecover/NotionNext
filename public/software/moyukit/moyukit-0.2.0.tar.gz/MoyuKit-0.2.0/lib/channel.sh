#!/usr/bin/env bash

MOYUKIT_BEGIN_MARK="${MOYUKIT_BEGIN_MARK:-# >>> MoyuKit >>>}"
MOYUKIT_END_MARK="${MOYUKIT_END_MARK:-# <<< MoyuKit <<<}"

moyukit_config_dir() {
    printf '%s\n' "${HOME}/.config/moyukit"
}

moyukit_channel_file() {
    printf '%s/channel\n' "$(moyukit_config_dir)"
}

moyukit_paths_file() {
    printf '%s/paths.conf\n' "$(moyukit_config_dir)"
}

moyukit_loader_file() {
    printf '%s/loader.sh\n' "$(moyukit_config_dir)"
}

moyukit_default_stable_home() {
    printf '%s\n' "${HOME}/.local/share/moyukit"
}

moyukit_default_dev_home() {
    printf '%s\n' "${HOME}/.local/share/moyukit-dev"
}

moyukit_shell_quote() {
    local value="$1"
    value="${value//\'/\'\\\'\'}"
    printf "'%s'" "$value"
}

moyukit_expand_path() {
    local input="$1"
    local parent base

    case "$input" in
        "~") input="$HOME" ;;
        "~/"*) input="$HOME/${input#~/}" ;;
    esac

    [[ -n "$input" ]] || return 1
    [[ "$input" != *$'\n'* ]] || return 1

    if [[ "$input" != /* ]]; then
        input="$PWD/$input"
    fi

    parent="$(dirname "$input")"
    base="$(basename "$input")"
    [[ "$base" != "." && "$base" != ".." ]] || return 1
    mkdir -p "$parent" || return 1
    parent="$(cd "$parent" && pwd -P)" || return 1
    printf '%s/%s\n' "$parent" "$base"
}

moyukit_resolve_existing_path() {
    local input="$1"
    local parent base

    case "$input" in
        "~") input="$HOME" ;;
        "~/"*) input="$HOME/${input#~/}" ;;
    esac

    [[ -n "$input" ]] || return 1
    [[ "$input" != *$'\n'* ]] || return 1

    if [[ "$input" != /* ]]; then
        input="$PWD/$input"
    fi

    parent="$(dirname "$input")"
    base="$(basename "$input")"
    [[ "$base" != "." && "$base" != ".." ]] || return 1
    parent="$(cd "$parent" && pwd -P)" || return 1
    printf '%s/%s\n' "$parent" "$base"
}

moyukit_assert_safe_user_dir() {
    local dir="$1"

    case "$dir" in
        ""|/|"$HOME"|/usr|/usr/*|/etc|/etc/*|/opt|/opt/*|/bin|/bin/*|/sbin|/sbin/*)
            return 1
            ;;
    esac

    return 0
}

moyukit_load_paths() {
    local paths_file line key value

    MOYUKIT_STABLE_HOME_PATH="$(moyukit_default_stable_home)"
    MOYUKIT_DEV_HOME_PATH="$(moyukit_default_dev_home)"
    paths_file="$(moyukit_paths_file)"

    [[ -r "$paths_file" ]] || return 0

    while IFS= read -r line || [[ -n "$line" ]]; do
        case "$line" in
            ""|\#*) continue ;;
            *=*)
                key="${line%%=*}"
                value="${line#*=}"
                ;;
            *) continue ;;
        esac

        [[ "$value" == /* && "$value" != *$'\n'* ]] || continue
        case "$key" in
            stable_home) MOYUKIT_STABLE_HOME_PATH="$value" ;;
            dev_home) MOYUKIT_DEV_HOME_PATH="$value" ;;
        esac
    done < "$paths_file"
}

moyukit_write_paths() {
    local stable_home="${1:-}"
    local dev_home="${2:-}"
    local config_dir paths_file tmp_file

    moyukit_load_paths
    [[ -n "$stable_home" ]] || stable_home="$MOYUKIT_STABLE_HOME_PATH"
    [[ -n "$dev_home" ]] || dev_home="$MOYUKIT_DEV_HOME_PATH"

    config_dir="$(moyukit_config_dir)"
    paths_file="$(moyukit_paths_file)"
    mkdir -p "$config_dir"
    tmp_file="$(mktemp "$config_dir/paths.conf.XXXXXX")" || return 1
    {
        printf 'stable_home=%s\n' "$stable_home"
        printf 'dev_home=%s\n' "$dev_home"
    } > "$tmp_file"
    mv "$tmp_file" "$paths_file"
}

moyukit_read_channel() {
    local channel_file channel

    channel_file="$(moyukit_channel_file)"
    if [[ -r "$channel_file" ]]; then
        IFS= read -r channel < "$channel_file" || channel="stable"
    else
        channel="stable"
    fi

    case "$channel" in
        stable|dev) printf '%s\n' "$channel" ;;
        *) printf 'stable\n' ;;
    esac
}

moyukit_write_channel() {
    local channel="$1"
    local config_dir channel_file tmp_file

    case "$channel" in
        stable|dev) ;;
        *) return 1 ;;
    esac

    config_dir="$(moyukit_config_dir)"
    channel_file="$(moyukit_channel_file)"
    mkdir -p "$config_dir"
    tmp_file="$(mktemp "$config_dir/channel.XXXXXX")" || return 1
    printf '%s\n' "$channel" > "$tmp_file"
    mv "$tmp_file" "$channel_file"
}

moyukit_channel_home() {
    local channel="$1"

    moyukit_load_paths
    case "$channel" in
        stable) printf '%s\n' "$MOYUKIT_STABLE_HOME_PATH" ;;
        dev) printf '%s\n' "$MOYUKIT_DEV_HOME_PATH" ;;
        *) return 1 ;;
    esac
}

moyukit_channel_init() {
    local channel="$1"
    local home

    home="$(moyukit_channel_home "$channel")" || return 1
    printf '%s/init.sh\n' "$home"
}

moyukit_channel_exists() {
    local channel="$1"
    local init_file

    init_file="$(moyukit_channel_init "$channel")" || return 1
    [[ -r "$init_file" ]]
}

moyukit_write_loader() {
    local config_dir loader_file tmp_file

    config_dir="$(moyukit_config_dir)"
    loader_file="$(moyukit_loader_file)"
    mkdir -p "$config_dir"
    tmp_file="$(mktemp "$config_dir/loader.sh.XXXXXX")" || return 1
    cat > "$tmp_file" <<'EOF'
#!/usr/bin/env bash

_moyukit_loader() {
    local config_dir paths_file channel_file channel stable_home dev_home target_home
    local line key value

    config_dir="${HOME}/.config/moyukit"
    paths_file="$config_dir/paths.conf"
    channel_file="$config_dir/channel"
    stable_home="${HOME}/.local/share/moyukit"
    dev_home="${HOME}/.local/share/moyukit-dev"

    if [[ -r "$paths_file" ]]; then
        while IFS= read -r line || [[ -n "$line" ]]; do
            case "$line" in
                ""|\#*) continue ;;
                *=*)
                    key="${line%%=*}"
                    value="${line#*=}"
                    ;;
                *) continue ;;
            esac

            [[ "$value" == /* && "$value" != *$'\n'* ]] || continue
            case "$key" in
                stable_home) stable_home="$value" ;;
                dev_home) dev_home="$value" ;;
            esac
        done < "$paths_file"
    fi

    if [[ -r "$channel_file" ]]; then
        IFS= read -r channel < "$channel_file" || channel="stable"
    else
        channel="stable"
    fi

    case "$channel" in
        stable) target_home="$stable_home" ;;
        dev) target_home="$dev_home" ;;
        *)
            echo "MoyuKit: 通道配置无效：$channel" >&2
            echo "MoyuKit: 请将 $channel_file 设置为 stable 或 dev。" >&2
            return 1
            ;;
    esac

    if [[ ! -r "$target_home/init.sh" ]]; then
        echo "MoyuKit: 当前通道 $channel 的安装不可用：$target_home" >&2
        echo "MoyuKit: 请安装该通道，或在可用通道中运行 moyu channel stable/dev 切换。" >&2
        return 1
    fi

    MOYUKIT_CHANNEL="$channel"
    export MOYUKIT_CHANNEL
    # shellcheck source=/dev/null
    source "$target_home/init.sh"
}

_moyukit_loader
unset -f _moyukit_loader
EOF
    chmod 0644 "$tmp_file"
    mv "$tmp_file" "$loader_file"
}

moyukit_write_bashrc_loader_block() {
    local bashrc="${HOME}/.bashrc"
    local tmp_file="$1"
    local backup_file

    if [[ -f "$bashrc" ]]; then
        awk -v begin="$MOYUKIT_BEGIN_MARK" -v end="$MOYUKIT_END_MARK" '
            $0 == begin {skip = 1; next}
            $0 == end {skip = 0; next}
            skip != 1 {print}
        ' "$bashrc" > "$tmp_file"
    else
        : > "$tmp_file"
    fi

    if [[ -s "$tmp_file" ]] && [[ -n "$(tail -n 1 "$tmp_file")" ]]; then
        printf '\n' >> "$tmp_file"
    fi

    {
        printf '%s\n' "$MOYUKIT_BEGIN_MARK"
        printf '[[ -r "$HOME/.config/moyukit/loader.sh" ]] && source "$HOME/.config/moyukit/loader.sh"\n'
        printf '%s\n' "$MOYUKIT_END_MARK"
    } >> "$tmp_file"

    if [[ -f "$bashrc" ]] && cmp -s "$bashrc" "$tmp_file"; then
        rm -f "$tmp_file"
        return 0
    fi

    if [[ -f "$bashrc" ]]; then
        backup_file="${bashrc}.moyukit.bak.$(date +%Y%m%d%H%M%S)"
        cp "$bashrc" "$backup_file"
        echo "MoyuKit: 已备份 .bashrc 到：$backup_file"
    fi

    mv "$tmp_file" "$bashrc"
}

moyukit_ensure_user_loader() {
    local stable_home="${1:-}"
    local dev_home="${2:-}"
    local default_channel="${3:-stable}"
    local tmp_file

    moyukit_write_paths "$stable_home" "$dev_home" || return 1
    moyukit_write_loader || return 1

    tmp_file="$(mktemp "${TMPDIR:-/tmp}/moyukit-bashrc.XXXXXX")" || return 1
    moyukit_write_bashrc_loader_block "$tmp_file" || return 1

    if [[ ! -e "$(moyukit_channel_file)" ]]; then
        moyukit_write_channel "$default_channel" || return 1
    fi
}

moyukit_remove_bashrc_block() {
    local bashrc="${HOME}/.bashrc"
    local tmp_file

    [[ -f "$bashrc" ]] || return 0
    tmp_file="$(mktemp "${TMPDIR:-/tmp}/moyukit-bashrc.XXXXXX")" || return 1
    awk -v begin="$MOYUKIT_BEGIN_MARK" -v end="$MOYUKIT_END_MARK" '
        $0 == begin {skip = 1; next}
        $0 == end {skip = 0; next}
        skip != 1 {print}
    ' "$bashrc" > "$tmp_file"

    if ! cmp -s "$bashrc" "$tmp_file"; then
        mv "$tmp_file" "$bashrc"
    else
        rm -f "$tmp_file"
    fi
}

moyukit_cleanup_shared_config_if_empty() {
    local config_dir loader_file channel_file paths_file
    local stable_home dev_home

    moyukit_load_paths
    stable_home="$MOYUKIT_STABLE_HOME_PATH"
    dev_home="$MOYUKIT_DEV_HOME_PATH"

    if [[ -r "$stable_home/init.sh" || -r "$dev_home/init.sh" ]]; then
        return 0
    fi

    config_dir="$(moyukit_config_dir)"
    loader_file="$(moyukit_loader_file)"
    channel_file="$(moyukit_channel_file)"
    paths_file="$(moyukit_paths_file)"
    rm -f "$loader_file" "$channel_file" "$paths_file"
    rmdir "$config_dir" 2>/dev/null || true
    moyukit_remove_bashrc_block
}
